export HIP_VISIBLE_DEVICES=4
echo debug_hyp_softmax_topk_y_soft_4
tune run eleuther_eval --config ./7B_eval_mod.yaml