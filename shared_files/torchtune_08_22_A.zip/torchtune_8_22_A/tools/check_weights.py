import os
from tututools.utils import getFiles

files = getFiles('exps')
for fname in files:
    if 'weights/hf_model_0002' in fname:
        exp_path = fname.split('weights/')[0]
        print(exp_path + 'weights')