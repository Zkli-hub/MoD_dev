export HIP_VISIBLE_DEVICES=6
echo "Process is working on: $HIP_VISIBLE_DEVICES"

# Scheme A: Only router training in Mixture-of-Depth
# tune run ./scripts/router_only_train.py --config ./configs/llama2_7B/7B_llama2_router_mod.yaml

# Scheme B: Update router and LoRA parameters
# tune run ./scripts/lora_train_dev.py --config ./configs/llama2_7B/7B_llama2_lora_mod.yaml

# Scheme C: Update router and all parameters
# tune run ./scripts/full_finetune_train.py --config ./configs/llama2_7B/7B_llama2_lora_mod.yaml

# Scheme D: Search the best capacity.
# tune run ./scripts/search_sr_train.py --config ./configs/llama2_7B/7B_llama2_SR_search.yaml

# Scheme E: Dump the data and sample from seq_len
# tune run ./scripts/data_sampler.py --config ./configs/utils/data_sampler.yaml

tune run ./scripts/_search_sr_worker.py --config ./configs/llama2_7B/7B_llama2_SR_search.yaml
