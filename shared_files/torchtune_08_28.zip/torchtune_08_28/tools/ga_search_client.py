import requests
import json
from multiprocessing import Process, Pool
import numpy as np
from sko.GA import GA

# for debug.
cap_data = {
    "cap_dict": {"layer_1": 0.1, "layer_2": 0.9, "layer_3": 0.9,"layer_4": 0.9,"layer_5": 0.9,"layer_6": 0.9,"layer_7": 0.9,"layer_8": 0.9,"layer_9": 0.9,"layer_10": 0.7,"layer_11": 0.7,"layer_12": 0.7,"layer_13": 0.7,"layer_14": 0.7,"layer_15": 0.7,"layer_16": 0.7,"layer_17": 0.7,"layer_18": 0.7,"layer_19": 0.7,"layer_20": 0.6,"layer_21": 0.6,"layer_22": 0.6,"layer_23": 0.6,"layer_24": 0.4,"layer_25": 0.4,"layer_26": 0.4,"layer_27": 0.4,"layer_28": 0.4,"layer_29": 0.4,"layer_30": 0.5}
}

api_url = f"http://127.0.0.1:8000/call"
res = requests.post(url = api_url, json=cap_data)
response = json.loads(res.text)
print(response)


# GPU_NUMBER = 8
# PARAM_MAPPER = {0: 'layer_1', 1: 'layer_2', 2: 'layer_3', 3: 'layer_4', 4: 'layer_5', 5: 'layer_6', 6: 'layer_7', 7: 'layer_8', 8: 'layer_9', 9: 'layer_10', 10: 'layer_11', 11: 'layer_12', 12: 'layer_13', 13: 'layer_14', 14: 'layer_15', 15: 'layer_16', 16: 'layer_17', 17: 'layer_18', 18: 'layer_19', 19: 'layer_20', 20: 'layer_21', 21: 'layer_22', 22: 'layer_23', 23: 'layer_24', 24: 'layer_25', 25: 'layer_26', 26: 'layer_27', 27: 'layer_28', 28: 'layer_29', 29: 'layer_30'}

# def api_agent(gpu_id, cap_data):
#     api_url = f"http://127.0.0.1:800{gpu_id}/call"
#     res = requests.post(url = api_url, json=cap_data)
#     response = json.loads(res.text)
#     return response

# def evaluate_ppl(_cap): # RPC to multi-GPUs
#     cap_data = {'cap_dict':{}}
#     for parma_id, c in enumerate(_cap): # _cap: [dims,]
#         cap_data["cap_dict"][PARAM_MAPPER[parma_id]] = c
#     with Pool() as pool:
#         async_results = [pool.apply_async(api_agent, (gpu_id, cap_data, )) for gpu_id in range(GPU_NUMBER)]
#         final_results = []
#         for res in async_results:
#             final_results.extend(res.get()['ppls'])
#     mean_ppl = np.mean(final_results)
#     return -1 * mean_ppl

# nga = GA(
#     func = evaluate_ppl,
#     n_dim = 30, 
#     size_pop = 200, # *6.73s -> 1, 
#     max_iter = 5, 
#     lb = 0, 
#     ub = 1,
#     prob_mut = 0.1,
#     precision = 1e-5,
# )

# best_params, best_ppl = nga.run()
# print('best_x:', best_params, '\n', 'best_ppl:', -best_ppl)
