#!/bin/bash

GPU_NUMBER=8
PORT=8000

nohup python tools/ppl_dist_worker.py --gpus $GPU_NUMBER --task_id 0 --port $PORT > /dev/null 2>&1 &
# nohup python tools/ppl_dist_worker.py --gpus $GPU_NUMBER --task_id 1 --port $[PORT+1] > /dev/null 2>&1 &
# nohup python tools/ppl_dist_worker.py --gpus $GPU_NUMBER --task_id 2 --port $[PORT+2] > /dev/null 2>&1 &
# nohup python tools/ppl_dist_worker.py --gpus $GPU_NUMBER --task_id 3 --port $[PORT+3] > /dev/null 2>&1 &
# nohup python tools/ppl_dist_worker.py --gpus $GPU_NUMBER --task_id 4 --port $[PORT+4] > /dev/null 2>&1 &
# nohup python tools/ppl_dist_worker.py --gpus $GPU_NUMBER --task_id 5 --port $[PORT+5] > /dev/null 2>&1 &
# nohup python tools/ppl_dist_worker.py --gpus $GPU_NUMBER --task_id 6 --port $[PORT+6] > /dev/null 2>&1 &
# nohup python tools/ppl_dist_worker.py --gpus $GPU_NUMBER --task_id 7 --port $[PORT+7] > /dev/null 2>&1 &

echo Workers are loading background, please wait for 120 seconds then call