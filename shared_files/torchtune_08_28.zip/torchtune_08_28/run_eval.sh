export HIP_VISIBLE_DEVICES=7
echo eval

tune run ./scripts/eval.py --config ./configs/llama2_7B/7B_llama2_eval.yaml
# tune run ./scripts/eval.py --config ./configs/qwen2_7B/7B_qwen2_eval.yaml
