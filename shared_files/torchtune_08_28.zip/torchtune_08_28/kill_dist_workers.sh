#!/bin/bash

ps aux | grep tools/ga_search_worker.py |  awk '{print $2}' | xargs kill -9