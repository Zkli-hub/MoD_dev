# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the BSD-style license found in the
# LICENSE file in the root directory of this source tree.

import os
import sys
import json
import shutil
import time
from functools import partial
from typing import Any, Dict, Optional, Tuple
from warnings import warn

import torch
from omegaconf import DictConfig, ListConfig

from torch import nn
from torch.optim import Optimizer
from torch.utils.data import DataLoader, DistributedSampler

from torchtune import config, modules, utils
from torchtune.datasets import ConcatDataset
from torchtune.recipe_interfaces import FTRecipeInterface
import pickle
from tqdm import tqdm, trange
import numpy as np

log = utils.get_logger("DEBUG")

class CapacityManager(object):
    def __init__(self, init_token_cap, all_cap_energy, overall_layer_num = 32):
        self._maintain = init_token_cap
        self._init_cap = init_token_cap
        self._all_cap_energy = all_cap_energy
        self.overall_layer_num = overall_layer_num
        self.mod_layer_num = len(init_token_cap.keys())
    
    def get_perturbation_token_cap(self, p = 0.05):
        perturbation = np.random.uniform(-1 * p, p, size = self.mod_layer_num)
        maintain_copy = {}
        for idx, (k, v) in enumerate(self._maintain.items()):
            new_v = v + perturbation[idx]
            maintain_copy[k] = float(np.float16(new_v))
        maintain_copy = self.re_normalize_cap(maintain_copy)
        return maintain_copy

    def mutation_on_random_one_layer(self, base_cap, p = 0.05):
        perturbation = np.random.uniform(-1 * p, p)
        new_cap_dict = {}
        mutation_point = np.random.randint(self.mod_layer_num)
        for idx, (k, v) in enumerate(base_cap.items()):
            if idx == mutation_point:
                new_v = v + perturbation
                new_cap_dict[k] = float(np.float16(new_v))
            else:
                new_cap_dict[k] = v
        new_cap_dict = self.re_normalize_cap(new_cap_dict)
        return new_cap_dict
    
    def crossover_caps(self, cap_dict_A, cap_dict_B, crossover_idx):
        new_cap_dict_A, new_cap_dict_B = {}, {}
        for idx, (k, v) in enumerate(cap_dict_A.items()):
            if idx >= crossover_idx:
                new_cap_dict_A[k] = v
                new_cap_dict_B[k] = cap_dict_B[k]
            else:
                new_cap_dict_A[k] = cap_dict_B[k]
                new_cap_dict_B[k] = v
        new_cap_dict_A = self.re_normalize_cap(new_cap_dict_A)
        new_cap_dict_B = self.re_normalize_cap(new_cap_dict_B)
        return new_cap_dict_A, new_cap_dict_B
    
    def update_maintained_token_cap(self, token_cap):
        self._maintain = token_cap

    def get_maintained_token_cap(self,):
        return self._maintain
    
    def get_inited_token_cap(self,):
        return self._init_cap
    
    def get_sr(self, cap_map):
        all_cap = 0
        for k, v in cap_map.items():
            all_cap += v
        ratio = 1 - (self.overall_layer_num - len(cap_map) + all_cap) / self.overall_layer_num
        return ratio

    def format_print(self, cap_map):
        for k, v in cap_map.items():
            print(k + ": " + "{:.4f}".format(v))
    
    def re_normalize_cap(self, cap_map):
        block_scores = torch.softmax(torch.tensor([v for _, v in cap_map.items()]), dim = 0)
        norm_scores = self._all_cap_energy * block_scores
        norm_scores = norm_scores.numpy()
        new_cap_map = {}
        for idx, (k, _) in enumerate(cap_map.items()):
            new_cap_map[k] = float(np.float16(norm_scores[idx]))
        return new_cap_map

class FullFinetuneRecipeSingleDevice(FTRecipeInterface):
    """
    Full finetuning recipe for dense transformer-based LLMs such as Llama2. This recipe is optimized
    for single GPU training. Training on CPU is not supported.

    Features:
        - Activation Checkpointing. This can be controlled using the ``activation_checkpointing``
            flag. Activation checkpointing helps reduce the memory footprint since we no longer keep
            activations in memory and instead recompute them during the backward pass. This is especially
            helpful for larger batch sizes when you're memory constrained. But these savings in memory
            come at the cost of training performance. In most cases training can slow-down quite a bit as
            a result of this activation recomputation.

        - Precision. Full fp32 and bf16 training are supported. Precision is controlled using the ``dtype``
            flag. When ``dtype=bf16``, all activations, gradients and optimizer states are in bfloat16. In
            most cases this should halve the memory footprint of full precision (fp32) training, without
            loss in model quality (will depend on the model, training data and other settings). For
            GPUs which do not support bfloat16, we fall back to fp32. Mixed precision training and fp16
            precision are currently not supported.

        - Gradient Accumulation. You can simulate larger batch sizes by accumulating gradients. This is
            controlled using the ``gradient_accumulation_steps`` flag.

                Total Batch Size = batch_size * gradient accumulation steps.

            For example: with batch_size=1 and gradient_accumulation_steps=32 we get a total batch size of 32.

            Gradient accumulation is especially useful when you are memory constrained. In this case,
            accumulating gradients might give you better training speed than enabling activation
            checkpointing.

        - Optimizer in Backward. Fusing the optimizer step into the backward pass helps reduce the memory
            footprint associated with gradients. This can be especially helpful when you are memory
            constrained. Note that users can only use ONE of gradient accumulation or optimizer in backward.
            These features currently do not work together. For more details on optimizer in backward, please
            see this tutorial: https://pytorch.org/tutorials/intermediate/optimizer_step_in_backward_tutorial.html

        - Lower precision optimizers. This recipe supports lower-precision optimizers from the bitsandbytes
            library (https://huggingface.co/docs/bitsandbytes/main/en/index). We've tested the recipe with
            8-bit AdamW and Paged AdamW. These optimizers are especially helpful when you are memory constrained
            since they help reduce the memory footprint associated with the optimizer states.

        - Checkpointing. Model weights are checkpointed both at the end of each epoch and at the end of
            training. Optimizer State and recipe state (seed, total_epochs, number of epochs run etc) are
            only saved at the end of a given epoch and used in case of resuming training.

            Resuming training is controlled by the ``resume_from_checkpoint`` flag. Mid-epoch checkpointing is
            currently not supported.

            For more details on the checkpointer, please take a look at
            our checkpointer deepdive (https://pytorch.org/torchtune/main/deep_dives/checkpointer.html).

        - Logging. Terminal, Disk, WandB and TensorBoard are all supported.

    For a full list of example configs for this recipe, run ``tune ls`` on the command line. Each config
    has example commands for how to kick-off training.

    Args:
        cfg (DictConfig): OmegaConf object parsed from yaml file

    Raises:
        RuntimeError: If ``dtype`` is set to fp16.
        RuntimeError: If ``dtype`` is set to bf16 and the hardware does not support bf16.
        RuntimeError: If ``gradient_accumulation_steps > 1`` and ``optimizer_in_bwd`` is `True`.
    """

    def __init__(self, cfg: DictConfig) -> None:
        self._device = utils.get_device(device=cfg.device)
        self._dtype = utils.get_dtype(cfg.dtype, device=self._device)
        # Disable for fp16, as we haven't validated "full" fp16 with this recipe, nor
        # enabled necessary features such as gradient scaling.
        if self._dtype == torch.float16:
            raise RuntimeError(
                "full fp16 training is not supported with this recipe. Please use bf16 or fp32 instead."
            )

        # logging attributes
        self._output_dir = cfg.output_dir
        self._log_every_n_steps = cfg.get("log_every_n_steps", 1)
        self._log_peak_memory_stats = cfg.get("log_peak_memory_stats", False)

        # Training cfg
        self._resume_from_checkpoint = cfg.resume_from_checkpoint
        self._gradient_accumulation_steps = cfg.gradient_accumulation_steps

        # These are public properties which are updated by the checkpoint loader
        # when ``resume_from_checkpoint`` is `True` or validated in tests
        self.seed = utils.set_seed(seed=cfg.seed)
        self.epochs_run = 0
        self.total_epochs = cfg.epochs
        self.max_steps_per_epoch = cfg.max_steps_per_epoch
        self.global_step = 0

        # This would overwrite the epoch setting
        self.cfg = cfg
        
    def load_checkpoint(self, cfg_checkpointer: DictConfig) -> Dict[str, Any]:
        """
        Extract the checkpoint state from file and validate. If resume_from_checkpoint
        is True, this also includes the recipe state.
        """
        self._checkpointer = config.instantiate(
            cfg_checkpointer,
            resume_from_checkpoint=self._resume_from_checkpoint,
        )
        checkpoint_dict = self._checkpointer.load_checkpoint()

        if self._resume_from_checkpoint:
            self._update_recipe_state(checkpoint_dict)
        return checkpoint_dict

    def _update_recipe_state(self, ckpt_dict: Dict[str, Any]) -> None:
        """
        Updates the recipe state from checkpoint.
        """
        try:
            self.epochs_run = ckpt_dict[utils.EPOCHS_KEY]

            # on mismatch, warn the user and prevent the override
            if self.seed != ckpt_dict[utils.SEED_KEY]:
                warn(
                    message=(
                        "Config value for seed does not match the checkpoint value, "
                        f"using the checkpoint value: {ckpt_dict[utils.SEED_KEY]}"
                    )
                )
                self.seed = ckpt_dict[utils.SEED_KEY]
            if self.max_steps_per_epoch != ckpt_dict[utils.MAX_STEPS_KEY]:
                warn(
                    message=(
                        "Config value for max_steps_per_epoch does not match the checkpoint value, "
                        f"using the checkpoint value: {ckpt_dict[utils.MAX_STEPS_KEY]}"
                    )
                )
                self.max_steps_per_epoch = ckpt_dict[utils.MAX_STEPS_KEY]

            # on mismatch, warn the user but allow the override
            if self.total_epochs != ckpt_dict[utils.TOTAL_EPOCHS_KEY]:
                warn(
                    message=(
                        "Config value for total_epochs does not match the checkpoint value, "
                        f"using the config value: {self.total_epochs}"
                    )
                )

        except KeyError as e:
            raise KeyError(
                "Checkpoint does not contain the required keys needed for updating recipe state. "
                "Are you sure you passed in the right recipe checkpoint?"
            ) from e

    def setup(self, cfg: DictConfig) -> None:
        """
        Sets up the recipe state correctly. This includes setting recipe attributes based
        on the ``resume_from_checkpoint`` flag.
        """
        self._metric_logger = config.instantiate(cfg.metric_logger)
        # log config with parameter override
        self._metric_logger.log_config(cfg)

        ckpt_dict = self.load_checkpoint(cfg.checkpointer)
        if cfg.codes_copy_backup.enable:
            shutil.copy(cfg.codes_copy_backup._code_src_path, os.path.join(cfg.output_dir, f'{cfg.exp_name}_core_code.py'))
            shutil.copy(cfg.codes_copy_backup._cfg_src_path, os.path.join(cfg.output_dir, f'{cfg.exp_name}_cfg.yaml'))
        
        # ``_setup_model`` handles initialization and loading the state dict. This method
        # should be called before ``_setup_optimizer`` since transforming the optimizer
        # state dict requires the model
        self._model_compile = cfg.compile
        self._model = self._setup_model(
            cfg_model=cfg.model,
            enable_activation_checkpointing=cfg.enable_activation_checkpointing,
            compile_model=self._model_compile,
            model_state_dict=ckpt_dict[utils.MODEL_KEY],
        )
        trainable_names = []
        for name, param in self._model.named_parameters():
            param.requires_grad = False

        log.info(f'The parameters which are trainable: {trainable_names}')

        self._tokenizer = config.instantiate(cfg.tokenizer)
        log.info("Tokenizer is initialized from file.")
        self._loss_fn = config.instantiate(cfg.loss)
        log.info("Loss is initialized.")

        # sampler and dataloader depend on the tokenizer and loss_fn and should be
        # setup after both of these are initialized
        self._sampler, self._dataloader = self._setup_data(
            cfg_dataset=cfg.dataset,
            shuffle=cfg.shuffle,
            batch_size=cfg.batch_size,
        )

        # Finally update the recipe state which can only be correctly set after all of the
        # other components have been initialized and updated.
        #
        # Number of training steps in each epoch depends on the number of batches produced
        # by the dataloader, the max_steps_per_epoch param set by the user and the
        # gradient_accumulation_steps param. This value is used for logging and tracking
        # training state. The computation should happen after the dataloader has been setup
        self._steps_per_epoch = (
            len(self._dataloader) // self._gradient_accumulation_steps
        )
        if (
            self.max_steps_per_epoch is not None
            and self.max_steps_per_epoch < self._steps_per_epoch
        ):
            self._steps_per_epoch = self.max_steps_per_epoch
        self.global_step = self.epochs_run * self._steps_per_epoch
    
    def calculate_sr(self, cap_map, overall_layer_num):
        all_cap = 0
        for k, v in cap_map.items():
            all_cap += v
        ratio = 1 - (overall_layer_num - len(cap_map) + all_cap) / overall_layer_num
        return ratio

    def _setup_model(
        self,
        cfg_model: DictConfig,
        enable_activation_checkpointing: bool,
        compile_model: bool,
        model_state_dict: Dict[str, Any],
    ) -> nn.Module:
        """
        Set up the model including enabling activation checkpointing.
        """
        with utils.set_default_dtype(self._dtype), self._device:
            model = config.instantiate(cfg_model)
        
        if enable_activation_checkpointing:
            utils.set_activation_checkpointing(
                model, auto_wrap_policy={modules.TransformerDecoderLayer}
            )

        model.load_state_dict(model_state_dict, strict = False)

        # Validate model was loaded in with the expected dtype.
        utils.validate_expected_param_dtype(model.named_parameters(), dtype=self._dtype)
        log.info(f"Model is initialized with precision {self._dtype}.")

        # Compile model, if enabled.
        if compile_model:
            log.info("Compiling model with torch.compile...")
            backend = os.environ.get("TORCH_COMPILE_BACKEND", "inductor")
            model.compile(backend=backend)
        if self._device.type == "cuda":
            memory_stats = utils.get_memory_stats(device=self._device)
            utils.log_memory_stats(memory_stats)
        
        model.setup_distillation_mode(self.cfg.distillation_mode)

        block_to_block_sim_scores = np.array(self.cfg.block_to_block_sim_scores)
        expected_SR = self.cfg.expected_SR
        overall_layer_num =  block_to_block_sim_scores.shape[0]
        mod_positions = np.arange(0,overall_layer_num)
        # Mod layer positions
        mod_positions = mod_positions[self.cfg.mod_positions.min_lid:self.cfg.mod_positions.max_lid + 1]
        mod_layer_num = len(mod_positions)

        block_importance = 1 - block_to_block_sim_scores
        block_importance = torch.from_numpy(block_importance)
        selected_block_importance = block_importance[mod_positions]
        selected_BI_weights = torch.softmax(selected_block_importance, dim = 0) # Scale to the values can be sum()=1

        avg_init_cap = (((1 - expected_SR) * overall_layer_num) + mod_layer_num - overall_layer_num) / mod_layer_num
        init_cap = avg_init_cap * mod_layer_num * selected_BI_weights
        init_cap = init_cap.numpy()

        init_cap_map_dict = {}
        for idx, li in enumerate(mod_positions):
            init_cap_map_dict['layer' + '_' + str(li)] = float(np.float16(init_cap[idx]))
        print(f'Init the selected layers: {init_cap_map_dict}, current SR: {self.calculate_sr(init_cap_map_dict, overall_layer_num)}')

        if self.cfg.mod_model_settings['token_capacity'] == None:
            print('No initial capacity given, so we init the cap from BI score')
            self.cfg.mod_model_settings['token_capacity'] = init_cap_map_dict

        model.setup_mod_settings(self.cfg.mod_model_settings)
        self.cap_manager = CapacityManager(self.cfg.mod_model_settings['token_capacity'], avg_init_cap * mod_layer_num) # init a manager

        return model

    def _setup_data(
        self,
        cfg_dataset: DictConfig,
        shuffle: bool,
        batch_size: int,
    ) -> Tuple[DistributedSampler, DataLoader]:
        """
        All data related setup happens here. Currently this recipe only supports the
        DistributedSamplers with Map-style Datasets which fit into memory. Other samplers,
        iterable datasets and streaming datasets are not supported.
        """
        if isinstance(cfg_dataset, ListConfig):
            datasets = [
                config.instantiate(single_cfg_dataset, tokenizer=self._tokenizer)
                for single_cfg_dataset in cfg_dataset
            ]
            ds = ConcatDataset(datasets=datasets)
            packed = False
        else:
            ds = config.instantiate(cfg_dataset, tokenizer=self._tokenizer)
            packed = cfg_dataset.get("packed", False)

        sampler = DistributedSampler(
            ds,
            num_replicas=1,
            rank=0,
            shuffle=shuffle,
            seed=0,
        )
        dataloader = DataLoader(
            dataset=ds,
            batch_size=batch_size,
            sampler=sampler,
            collate_fn=partial(
                utils.padded_collate,
                padding_idx=self._tokenizer.pad_id,
                ignore_idx=self._loss_fn.ignore_index,
            )
            if not packed
            else None,
        )

        log.info("Dataset and Sampler are initialized.")
        return sampler, dataloader

    def evaluate_ppl(self, token_cap_dict = None):
        cur_ppl = []
        mod_model_settings = self.cfg.mod_model_settings
        if token_cap_dict != None:
            mod_model_settings['token_capacity'] = token_cap_dict
        self._model.setup_mod_settings(mod_model_settings)
        with torch.no_grad():
            with open('dump_data.pkl', 'rb') as f:
                dump_data = pickle.load(f)

            tokens_list, labels_list, input_pos_list, mask_list = dump_data['tokens_list'], dump_data['labels_list'], dump_data['input_pos_list'], dump_data['mask_list']
            for tokens, labels, input_pos, mask in zip(tokens_list, labels_list, input_pos_list, mask_list):
                tokens = tokens.to(self._device)
                labels = labels.to(self._device)
                mask = mask.to(self._device) if mask is not None else None
                input_pos = (
                    input_pos.to(self._device) if input_pos is not None else None
                )
                logits = self._model(tokens, mask=mask, input_pos=input_pos)
                # Shift so that tokens < n predict n
                logits = logits[..., :-1, :].contiguous()
                labels = labels[..., 1:].contiguous()
                logits = logits.transpose(1, 2) # NOTE, torchtune, impl.

                loss = self._loss_fn(logits, labels)
                loss = torch.exp(loss) # following `Blockpruner`
                cur_ppl.append(loss)
        cur_ppl = torch.stack(cur_ppl, dim = 0)
        ppl = torch.mean(cur_ppl)
        return ppl, cur_ppl

    def train(self) -> None:
        """
        The core training loop. Supports training on subsets of the dataset using the
        ``max_steps_per_epoch``.
        """
        if self._model_compile:
            log.info(
                "NOTE: torch.compile is enabled and model is compiled in first forward. Expect a relatively slow first iteration."
            )
        self._model.clone_undamaged_layers() # clone the layers for distillation.
        
        # p, task_id, 
        

        ppl, cur_ppl = self.evaluate_ppl(p)
        tmp_root = self.cfg.tmp_root # './__tmp_multi_gpus__'
        if os.path.exists(join(tmp_root, self.cfg.generation_id, 'results')) == False:
            os.makedirs(join(tmp_root, self.cfg.generation_id, 'results'), exist_ok = True)

        join = os.path.join
        with open(join(tmp_root, self.cfg.generation_id, 'results', self.cfg.population_id_path), 'wb') as f:
            f.write("{:.4f}".format(ppl.item()))

    def cleanup(self) -> None:
        self._metric_logger.close()


@config.parse
def recipe_main(cfg: DictConfig) -> None:
    """
    Entry point for the recipe.

    Configurable parameters are read in the following order:
        - Parameters specified in config (see available configs through ``tune ls``)
        - Overwritten by arguments from the command-line
    """
    config.log_config(recipe_name="FullFinetuneRecipeSingleDevice", cfg=cfg)
    recipe = FullFinetuneRecipeSingleDevice(cfg=cfg)
    recipe.setup(cfg=cfg)
    recipe.train()
    recipe.cleanup()


if __name__ == "__main__":
    sys.exit(recipe_main())
