
import json
import torch.utils
import torch.utils.data
from torchtune import config, modules, utils
from omegaconf import DictConfig
import lightning as L
import torch
import pickle
import requests
import json
import argparse
import lm_eval
from lm_eval.models.huggingface import HFLM
from lm_eval.tasks import get_task_dict, TaskManager
from lm_eval.utils import make_table
from typing import Any, Dict, List, Tuple, Union
from torchtune.modules.tokenizers import ModelTokenizer
from torch.nn.utils.rnn import pad_sequence
import itertools
import json
import logging
import random
import time
from collections import defaultdict
from typing import TYPE_CHECKING, List, Optional, Union
import lm_eval.api.metrics
import lm_eval.api.registry
import lm_eval.models
from lm_eval.caching.cache import delete_cache
from lm_eval.evaluator_utils import (
    consolidate_results,
    get_sample_size,
    get_task_list,
    prepare_print_tasks,
    print_writeout,
    run_task_tests,
)
from lm_eval.loggers import EvaluationTracker
from lm_eval.loggers.utils import add_env_info, add_tokenizer_info, get_git_commit_hash
from lm_eval.tasks import TaskManager, get_task_dict
from lm_eval.utils import (
    eval_logger,
    handle_non_serializable,
    hash_string,
    positional_deprecated,
    simple_parse_args_string,
)
if TYPE_CHECKING:
    from lm_eval.api.model import LM
    from lm_eval.tasks import Task
import numpy as np
from multiprocessing import Process, Pool

cfg_dict ={
    "data_pkl": "dump_data.pkl",
    "model":{"_component_": "torchtune.models.llama2.llama2_7b_mod"},
    "native_llama_path":  "./llama-2-7b-hf",
    "tokenizer":{
        "_component_": "torchtune.models.llama2.llama2_tokenizer",
        "path": "<native_llama_path>/tokenizer.model"
    },
    "checkpointer":{
        "_component_": "torchtune.utils.FullModelHFCheckpointer",
        "checkpoint_dir": "./llama-2-7b-hf",
        "checkpoint_files": [
            "pytorch_model-00001-of-00002.bin",
            "pytorch_model-00002-of-00002.bin"
        ],
        "adapter_checkpoint": None,
        "recipe_checkpoint": None,
        "output_dir": "",
        "model_type": "LLAMA2"
    },
    "exp_tag": "position",
    "prefix_num": 1,
    "cap": {"layer_1": 0.9, "layer_2": 0.9, "layer_3": 0.9,"layer_4": 0.9,"layer_5": 0.9,"layer_6": 0.9,"layer_7": 0.9,"layer_8": 0.9,"layer_9": 0.9,"layer_10": 0.7,"layer_11": 0.7,"layer_12": 0.7,"layer_13": 0.7,"layer_14": 0.7,"layer_15": 0.7,"layer_16": 0.7,"layer_17": 0.7,"layer_18": 0.7,"layer_19": 0.7,"layer_20": 0.6,"layer_21": 0.6,"layer_22": 0.6,"layer_23": 0.6,"layer_24": 0.4,"layer_25": 0.4,"layer_26": 0.4,"layer_27": 0.4,"layer_28": 0.4,"layer_29": 0.4,"layer_30": 0.5}
    # NOTE, A dumpy cap setting, if called from clients, this would be covered.
}

def api_agent(msg):
    gpu_id, send_data = msg
    api_url = f"http://127.0.0.1:800{gpu_id}/run_benchmark"
    res = requests.post(url = api_url, json=send_data)
    card_meta_decoded = pickle.loads(res.content)
    results = (gpu_id, card_meta_decoded[0])
    return results

@positional_deprecated
def evaluate(
    task_dict,
    cap_dict = None,
    limit: Optional[int] = None,
    cache_requests: bool = False,
    rewrite_requests_cache: bool = False,
    bootstrap_iters: Optional[int] = 100000,
    write_out: bool = False,
    log_samples: bool = True,
    system_instruction: Optional[str] = None,
    apply_chat_template: bool = False,
    fewshot_as_multiturn: bool = False,
    verbosity: str = "INFO",
):
    eval_logger.setLevel(getattr(logging, f"{verbosity}"))

    # tracks all Instances/requests a model must generate output on.
    requests = defaultdict(list)
    # stores the amount to pad out reqs per req. type so that
    # number of fwd passes per distributed rank is equal
    padding_requests = defaultdict(int)

    # get lists of group hierarchy and each type of request
    task_hierarchy, eval_tasks = get_task_list(task_dict)
    if not log_samples:
        if not all(
            "bypass" not in getattr(task_output.task, "_metric_fn_list", {}).keys()
            for task_output in eval_tasks
        ):
            raise ValueError("log_samples must be True for 'bypass' metric-only tasks")
    for task_output in eval_tasks:
        task: Task = task_output.task
        limit = get_sample_size(task, limit)
        task.build_all_requests(
            limit=limit,
            rank=0,
            world_size=1,
            cache_requests=cache_requests,
            rewrite_requests_cache=rewrite_requests_cache,
            system_instruction=system_instruction,
            apply_chat_template=apply_chat_template,
            fewshot_as_multiturn=fewshot_as_multiturn,
            chat_template=None,
            tokenizer_name="",
        )
        eval_logger.debug(
            f"Task: {task_output.task_name}; number of requests on this rank: {len(task.instances)}"
        )
        if write_out:
            print_writeout(task)
        # aggregate Instances by LM method requested to get output.
        for instance in task.instances:
            reqtype = instance.request_type
            requests[reqtype].append(instance)

        

    ### Run LM on inputs, get all outputs ###
    # execute each type of request
    for reqtype, reqs in requests.items():
        eval_logger.info(f"Running {reqtype} requests on {GPU_NUMBER} GPUs, please wait...")
        # # create `K` copies of each request `req` based off `K = req.repeats`
        cloned_reqs = []
        for req in reqs:
            cloned_reqs.extend([req] * req.repeats)

        tasks_data = {
            "task_names": TASK_NAMES,
            "infer_cfg":
            {
                "exp_tag": EXP_TAG,
                "prefix_num": PREFIX_NUM,
                "cap": cap_dict           
            }
        }

        with Pool(GPU_NUMBER) as pool:
            final_results = []
            sync_results = pool.map(api_agent, [(gpu_id, tasks_data) for gpu_id in range(GPU_NUMBER)]) # slower, but more stable than async
            sync_results = sorted(sync_results, key=lambda x: x[0]) # sorted by gpuid
            for re in sync_results:
                final_results.extend(re[1])
        resps = final_results
        # # run requests through model
        # resps = getattr(lm, reqtype)(cloned_reqs)
        
        # put responses from model into a list of length K for each request.
        for x, req in zip(resps, cloned_reqs):
            req.resps.append(x)


    # with open('temp_results.pkl', 'wb') as _f:
    #     pickle.dump(_meta_pack, _f)

    RANK = 0
    WORLD_SIZE = 1
    ### Postprocess outputs ###
    # TODO: del model here, maybe (idea: allow user to specify device of e.g. reward model separately)
    for task_output in eval_tasks:
        task = task_output.task
        task.apply_filters()

        ### Collect values of metrics on all datapoints ###
        # # unpack results and sort back in order and return control to Task
        # TODO: make it possible to use a different metric per filter
        # Pre-process task.instances to group by doc_id
        instances_by_doc_id = defaultdict(list)
        for instance in task.instances:
            instances_by_doc_id[instance.doc_id].append(instance)
        # Sort instances within each group
        for instances in instances_by_doc_id.values():
            instances.sort(key=lambda x: x.idx)
        # iterate over different filters used
        for filter_key in task.instances[0].filtered_resps.keys():
            doc_iterator = task.doc_iterator(
                rank=RANK, limit=limit, world_size=WORLD_SIZE
            )
            for doc_id, doc in doc_iterator:
                requests = instances_by_doc_id[doc_id]
                metrics = task.process_results(
                    doc, [req.filtered_resps[filter_key] for req in requests]
                )
                if log_samples:
                    target = task.doc_to_target(doc)
                    example = {
                        "doc_id": doc_id,
                        "doc": doc,
                        "target": target,
                        "arguments": [req.args for req in requests],
                        "resps": [req.resps for req in requests],
                        "filtered_resps": [
                            req.filtered_resps[filter_key] for req in requests
                        ],
                        "doc_hash": hash_string(
                            json.dumps(
                                requests[0].doc,
                                indent=2,
                                default=handle_non_serializable,
                                ensure_ascii=False,
                            )
                        ),
                        "prompt_hash": hash_string(requests[0].arguments[0]),
                        "target_hash": hash_string(str(target)),
                    }
                    example.update(metrics)
                    task_output.logged_samples.append(example)
                for metric, value in metrics.items():
                    task_output.sample_metrics[(metric, filter_key)].append(value)

    if WORLD_SIZE > 1:
        # if multigpu, then gather data across all ranks to rank 0
        # first gather logged samples across all ranks
        for task_output in eval_tasks:
            if log_samples:
                # for task_name, task_samples in list(samples.items()):
                full_samples = [None] * WORLD_SIZE if RANK == 0 else None
                torch.distributed.gather_object(
                    obj=task_output.logged_samples,
                    object_gather_list=full_samples,
                    dst=0,
                )

                if RANK == 0:
                    task_output.logged_samples = list(
                        itertools.chain.from_iterable(full_samples)
                    )

            # then collect metrics across all ranks
            for metrics in task_output.sample_metrics:
                metric_list = [None] * WORLD_SIZE if RANK == 0 else None
                torch.distributed.gather_object(
                    obj=task_output.sample_metrics[metrics],
                    object_gather_list=metric_list,
                    dst=0,
                )
                if RANK == 0:
                    task_output.sample_metrics[metrics] = list(
                        itertools.chain.from_iterable(metric_list)
                    )

    if RANK == 0:
        ### Aggregate results over all datapoints ###
        # aggregate results ; run bootstrap CIs
        for task_output in eval_tasks:
            task_output.calculate_aggregate_metric(bootstrap_iters=bootstrap_iters)
        (
            results,
            samples,
            configs,
            versions,
            num_fewshot,
            higher_is_better,
        ) = consolidate_results(eval_tasks)

        ### Calculate group metrics ###
        if bool(results):
            for group, task_list in reversed(task_hierarchy.items()):
                if len(task_list) == 0:
                    # task_hierarchy entries are either
                    # `group_name: [subtask1, subtask2, ...]`
                    # or `task_name: []`.
                    # we only want to operate on groups here.
                    continue

                # collect all higher_is_better values for metrics
                # in the group's subtasks.
                # TODO: clean this up ; unify with the below metric_list loop?
                _higher_is_better = {}
                for task in task_list:
                    for m, h in higher_is_better[task].items():
                        if m not in _higher_is_better.keys():
                            _higher_is_better[m] = h
                    if (
                        m in _higher_is_better
                        and _higher_is_better[m] is not None
                        and _higher_is_better[m] != h
                    ):
                        eval_logger.warning(
                            f"Higher_is_better values for metric {m} in group {group} are not consistent. Defaulting to None."
                        )
                        _higher_is_better[m] = None
                higher_is_better[group] = _higher_is_better

                # collect all metric keys used by a subtask in the group.
                metric_list = list(
                    {
                        key
                        for task in task_list
                        for key in results[task].keys()
                        if "_stderr" not in key and key not in ["alias", "samples"]
                    }
                )
                for metric in metric_list:
                    stderr = "_stderr,".join(metric.split(","))

                    # gather metrics, sizes, and stderrs from subtasks
                    metrics = [
                        results[task][metric]
                        for task in task_list
                        if metric in results[task]
                    ]  # TODO: copy?
                    stderrs = [
                        results[task][stderr]
                        for task in task_list
                        if stderr in results[task]
                    ]
                    sizes = [
                        results[task]["samples"]
                        for task in task_list
                        if metric in results[task]
                    ]

                    # compute group's pooled metric and stderr
                    results[group][metric] = (
                        lm_eval.api.metrics.aggregate_subtask_metrics(metrics, sizes)
                    )
                    # TODO: calculate grouped metric using aggregation fn
                    if "N/A" in stderrs:
                        results[group][stderr] = "N/A"
                    else:
                        results[group][stderr] = (
                            lm_eval.api.metrics.pooled_sample_stderr(stderrs, sizes)
                        )
                        # TODO: allow GroupConfigs to choose which variance formula is used, for back-compatibility
                        # To use the old (likely incorrect) variance formula, comment out the above and uncomment this line:
                        # results[group][stderr] = lm_eval.api.metrics.combined_sample_stderr(stderrs, sizes, metrics=metrics)

                    results[group]["samples"] = sum(sizes)

        results_agg = defaultdict(dict)
        groups_agg = defaultdict(dict)
        all_tasks_list = list(task_hierarchy.keys())
        while True:
            add_tasks_list = list(k for k in results_agg.keys())
            left_tasks_list = sorted(list(set(all_tasks_list) - set(add_tasks_list)))
            if len(left_tasks_list) == 0:
                break

            _task_hierarchy = {
                k: v for k, v in task_hierarchy.items() if k in left_tasks_list
            }
            _results_agg, _groups_agg = prepare_print_tasks(_task_hierarchy, results)

            results_agg = {**results_agg, **_results_agg}
            groups_agg = {**groups_agg, **_groups_agg}

        for group_name, task_list in task_hierarchy.items():
            if task_list:
                num_fewshot[group_name] = num_fewshot[
                    task_list[0]
                ]  # TODO: validate this

        results_dict = {
            "results": dict(results_agg.items()),
            **({"groups": dict(groups_agg.items())} if bool(groups_agg) else {}),
            "group_subtasks": dict(reversed(task_hierarchy.items())),
            "configs": dict(sorted(configs.items())),
            "versions": dict(sorted(versions.items())),
            "n-shot": dict(sorted(num_fewshot.items())),
            "higher_is_better": dict(sorted(higher_is_better.items())),
            "n-samples": {
                task_output.task_name: {
                    "original": len(task_output.task.eval_docs),
                    "effective": min(
                        limit if limit else len(task_output.task.eval_docs),
                        len(task_output.task.eval_docs),
                    ),
                }
                for task_output in eval_tasks
            },
        }
        if log_samples:
            results_dict["samples"] = dict(samples)

        return results_dict

    else:
        return None

TASK_NAMES = ["winogrande"]
GPU_NUMBER = 6
PREFIX_NUM = 1
EXP_TAG = "position"

def eval_benchmark(cap_dict):
    _tasks = TASK_NAMES
    _num_fewshots = {
        "winogrande":0,
        "arc_challenge":0,
        "arc_easy":0,
        "mmlu":5,
        "hellaswag":0,
    }
    try:
        lm_eval.tasks.initialize_tasks()
    except Exception:
        pass
    task_manager = TaskManager(include_path=None)
    task_dict = get_task_dict(_tasks, task_manager)
    for task_name in task_dict.keys():
        task_obj = task_dict[task_name]
        if isinstance(task_obj, tuple):
            _, task_obj = task_obj
            if task_obj is None:
                continue
        # override tasks' fewshot values to the provided num_fewshot arg value
        # except if tasks have it set to 0 manually in their configs--then we should never overwrite that
        if _num_fewshots[task_name] != 0:
            task_obj.set_config(key="num_fewshot", value=_num_fewshots[task_name])
        else:
            # if num_fewshot not provided, and the task does not define a default one, default to 0
            if (default_num_fewshot := task_obj.get_config("num_fewshot")) is None:
                task_obj.set_config(key="num_fewshot", value=0)
        # fewshot_random_seed set for tasks, even with a default num_fewshot (e.g. in the YAML file)
        task_obj.set_fewshot_seed(seed=1234)

    output_final = evaluate(
        task_dict,
        cap_dict = cap_dict,
        limit = None,
    )
    format_final = make_table(output_final)
    print(format_final)
    return output_final, format_final






if __name__ == "__main__":
    cap_dict = {"layer_1": 0.9, "layer_2": 0.9, "layer_3": 0.9,"layer_4": 0.9,"layer_5": 0.9,"layer_6": 0.9,"layer_7": 0.9,"layer_8": 0.9,"layer_9": 0.9,"layer_10": 0.7,"layer_11": 0.7,"layer_12": 0.7,"layer_13": 0.7,"layer_14": 0.7,"layer_15": 0.7,"layer_16": 0.7,"layer_17": 0.7,"layer_18": 0.7,"layer_19": 0.7,"layer_20": 0.6,"layer_21": 0.6,"layer_22": 0.6,"layer_23": 0.6,"layer_24": 0.4,"layer_25": 0.4,"layer_26": 0.4,"layer_27": 0.4,"layer_28": 0.4,"layer_29": 0.4,"layer_30": 0.5} 
    eval_benchmark(cap_dict)


