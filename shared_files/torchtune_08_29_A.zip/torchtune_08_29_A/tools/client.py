import requests
import json
import pickle

cap_data = {
    "cap_dict": {"layer_1": 0.1, "layer_2": 0.9, "layer_3": 0.9,"layer_4": 0.9,"layer_5": 0.9,"layer_6": 0.9,"layer_7": 0.9,"layer_8": 0.9,"layer_9": 0.9,"layer_10": 0.7,"layer_11": 0.7,"layer_12": 0.7,"layer_13": 0.7,"layer_14": 0.7,"layer_15": 0.7,"layer_16": 0.7,"layer_17": 0.7,"layer_18": 0.7,"layer_19": 0.7,"layer_20": 0.6,"layer_21": 0.6,"layer_22": 0.6,"layer_23": 0.6,"layer_24": 0.4,"layer_25": 0.4,"layer_26": 0.4,"layer_27": 0.4,"layer_28": 0.4,"layer_29": 0.4,"layer_30": 0.5}
}

# api_url = "http://127.0.0.1:8000/get_ppl_from_alpaca_256"
api_url = "http://127.0.0.1:8000/run_benchmark"
res = requests.post(url = api_url, json = cap_data)
card_meta_decoded = pickle.loads(res.content)
