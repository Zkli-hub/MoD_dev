
import json
import torch.utils
import torch.utils.data
from torchtune import config, modules, utils
from omegaconf import DictConfig
import lightning as L
import torch
import pickle
from flask import Flask,request,jsonify
import json
import argparse
import lm_eval
from lm_eval.models.huggingface import HFLM
from lm_eval.tasks import get_task_dict, TaskManager
from lm_eval.utils import make_table
from typing import Any, Dict, List, Tuple, Union
from torchtune.modules.tokenizers import ModelTokenizer
from torch.nn.utils.rnn import pad_sequence
import itertools
import json
import logging
import random
import time
from collections import defaultdict
from typing import TYPE_CHECKING, List, Optional, Union
import lm_eval.api.metrics
import lm_eval.api.registry
import lm_eval.models
from lm_eval.caching.cache import delete_cache
from lm_eval.evaluator_utils import (
    consolidate_results,
    get_sample_size,
    get_task_list,
    prepare_print_tasks,
    print_writeout,
    run_task_tests,
)
from lm_eval.loggers import EvaluationTracker
from lm_eval.loggers.utils import add_env_info, add_tokenizer_info, get_git_commit_hash
from lm_eval.tasks import TaskManager, get_task_dict
from lm_eval.utils import (
    eval_logger,
    handle_non_serializable,
    hash_string,
    positional_deprecated,
    simple_parse_args_string,
)
if TYPE_CHECKING:
    from lm_eval.api.model import LM
    from lm_eval.tasks import Task
import numpy as np

cfg_dict ={
    "data_pkl": "dump_data.pkl",
    "model":{"_component_": "torchtune.models.llama2.llama2_7b_mod"},
    "native_llama_path":  "./llama-2-7b-hf",
    "tokenizer":{
        "_component_": "torchtune.models.llama2.llama2_tokenizer",
        "path": "<native_llama_path>/tokenizer.model"
    },
    "checkpointer":{
        "_component_": "torchtune.utils.FullModelHFCheckpointer",
        "checkpoint_dir": "./llama-2-7b-hf",
        "checkpoint_files": [
            "pytorch_model-00001-of-00002.bin",
            "pytorch_model-00002-of-00002.bin"
        ],
        "adapter_checkpoint": None,
        "recipe_checkpoint": None,
        "output_dir": "",
        "model_type": "LLAMA2"
    },
    "exp_tag": "position",
    "prefix_num": 1,
    "cap": {"layer_1": 0.9, "layer_2": 0.9, "layer_3": 0.9,"layer_4": 0.9,"layer_5": 0.9,"layer_6": 0.9,"layer_7": 0.9,"layer_8": 0.9,"layer_9": 0.9,"layer_10": 0.7,"layer_11": 0.7,"layer_12": 0.7,"layer_13": 0.7,"layer_14": 0.7,"layer_15": 0.7,"layer_16": 0.7,"layer_17": 0.7,"layer_18": 0.7,"layer_19": 0.7,"layer_20": 0.6,"layer_21": 0.6,"layer_22": 0.6,"layer_23": 0.6,"layer_24": 0.4,"layer_25": 0.4,"layer_26": 0.4,"layer_27": 0.4,"layer_28": 0.4,"layer_29": 0.4,"layer_30": 0.5}
    # NOTE, A dumpy cap setting, if called from clients, this would be covered.
}


class _EvalWrapper(HFLM):
    """An EvalWrapper for EleutherAI's eval harness based on gpt-fast's
    EvalWrapper: https://github.com/pytorch-labs/gpt-fast/blob/main/eval.py.

    Args:
        model (TransformerDecoder): The model to evaluate.
        tokenizer (ModelTokenizer): Tokenizer associated with the model being evaluated.
            This should be the same tokenizer used when fine-tuning the model.
        device (torch.device): The device to use.
        max_seq_length (int): The maximum sequence length to use.
        batch_size (int): The batch size per GPU to use.
    """

    def __init__(
        self,
        model,
        tokenizer: ModelTokenizer,
        *,
        device: torch.device,
        max_seq_length: int = 4096,
        batch_size: int = 8,
        dtype: torch.dtype = torch.float32,
    ):
        super().__init__(pretrained="gpt2", device=str(device))
        print(model)
        self._model = model
        self._tokenizer = tokenizer
        self._max_seq_length = max_seq_length
        self._batch_size = batch_size
        self._dtype = dtype

    @property
    def model(self):
        return self._model

    @property
    def eot_token_id(self):
        return self._tokenizer.eos_id

    @property
    def max_length(self):
        return self._max_seq_length

    @property
    def max_gen_toks(self):
        return 256

    @property
    def batch_size(self):
        return self._batch_size

    @property
    def device(self):
        return self._device

    def tok_encode(self, text: str, **kwargs) -> List[int]:
        # Note on add_bos flag: setting to False as this gives better results, for example
        # +1% on truthfulqa_mc2 with a LoRA finetune. lit-gpt also sets this to False,
        # see https://github.com/Lightning-AI/lit-gpt/blob/main/eval/lm_eval_harness.py#L66,
        # though notably fast-gpt does the opposite
        # https://github.com/pytorch-labs/gpt-fast/blob/main/eval.py#L123.
        return self._tokenizer.encode(text=text, add_bos=False, add_eos=False)

    def tok_batch_encode(
        self, text: List[str], **kwargs
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        tokenized_text = [self.tok_encode(x) for x in text]

        # pad left
        x = pad_sequence(
            [
                torch.tensor(x[::-1]) for x in tokenized_text
            ],  # first flip each sequence and pad
            batch_first=True,
            padding_value=self._tokenizer.pad_id,
        ).flip(
            dims=[1]
        )  # flip back to correct order

        return x, torch.ones_like(x)  # return 'mask' b/c it's expected by the harness

    def tok_decode(self, tokens: Union[List[int], int], **kwargs) -> str:
        if isinstance(tokens, int):
            tokens = [tokens]
        return self._tokenizer.decode(tokens)

    def _model_call(self, inps: torch.Tensor, **kwargs) -> torch.Tensor:
        return self._model(inps)

    def _model_generate(
        self, context: torch.Tensor, **generation_kwargs
    ) -> torch.Tensor:
        curr_batch_size = context.size(0)

        # Setup caches for a given batch size
        # Technically this is not necessary, but it's a good way to ensure that
        # the caches won't error on a different batch size. In addition, caches
        # are not needed for a regular model call, so we just setup here
        with context.device:
            self._model.setup_caches(batch_size=curr_batch_size, dtype=self._dtype)

        temperature = generation_kwargs.get("temperature", 0.0)
        do_sample = generation_kwargs.get("do_sample", False)
        if do_sample:
            # do_sample signifies more complicated sampling logic, like top_k or
            # top_p. We don't support this yet, so if it's requested, we raise an error.
            raise RuntimeError(
                "``do_sample`` for generation tasks is not supported yet in torchtune."
            )

        toks = utils.generate(
            self._model,
            context,
            max_generated_tokens=self.max_gen_toks,
            pad_id=self._tokenizer.pad_id,
            temperature=temperature,
            top_k=None,  # do_sample is not supported currently
            stop_tokens=self._tokenizer.stop_tokens,
        )
        return torch.tensor(toks, dtype=torch.int32)

    def set_cap_info(self, cfg):
        process_cap_map = {}
        for k,v in cfg['cap'].items():
            process_cap_map[k.split('_')[1]] = v
        self._model.process_cap_map = process_cap_map
        self._model.exp_tag = cfg['exp_tag']
        self._model.prefix_num = cfg['prefix_num']
        self._model.postfix_num = cfg['postfix_num']

@positional_deprecated
def evaluate(
    lm: "LM",
    task_dict,
    limit: Optional[int] = None,
    cache_requests: bool = False,
    rewrite_requests_cache: bool = False,
    bootstrap_iters: Optional[int] = 100000,
    write_out: bool = False,
    log_samples: bool = True,
    system_instruction: Optional[str] = None,
    apply_chat_template: bool = False,
    fewshot_as_multiturn: bool = False,
    verbosity: str = "INFO",
):
    """Instantiate and evaluate a model on a list of tasks.

    :param lm: obj
        Language Model
    :param task_dict: dict[str, Task]
        Dictionary of tasks. Tasks will be taken to have name type(task).config.task .
    :param limit: int, optional
        Limit the number of examples per task (only use this for testing)
    :param bootstrap_iters:
        Number of iterations for bootstrap statistics, used when calculating stderr. Set to 0 for skipping all stderr calculations.
    :param write_out: bool
        If True, write out an example document and model input for checking task integrity
    :param log_samples: bool
        If True, write out all model outputs and documents for per-sample measurement and post-hoc analysis
    :param system_instruction: str
        System instruction to be applied to the prompt
    :param apply_chat_template: bool
        If True, apply chat template to the prompt
    :param fewshot_as_multiturn: bool
        Whether to provide the fewshot examples as a multiturn conversation or a single user turn.
    :return
        Dictionary of results
    """

    eval_logger.setLevel(getattr(logging, f"{verbosity}"))

    # tracks all Instances/requests a model must generate output on.
    requests = defaultdict(list)
    # stores the amount to pad out reqs per req. type so that
    # number of fwd passes per distributed rank is equal
    padding_requests = defaultdict(int)

    # get lists of group hierarchy and each type of request
    task_hierarchy, eval_tasks = get_task_list(task_dict)
    if not log_samples:
        if not all(
            "bypass" not in getattr(task_output.task, "_metric_fn_list", {}).keys()
            for task_output in eval_tasks
        ):
            raise ValueError("log_samples must be True for 'bypass' metric-only tasks")
    for task_output in eval_tasks:
        task: Task = task_output.task
        limit = get_sample_size(task, limit)
        task.build_all_requests(
            limit=limit,
            rank=lm.rank,
            world_size=lm.world_size,
            cache_requests=cache_requests,
            rewrite_requests_cache=rewrite_requests_cache,
            system_instruction=system_instruction,
            apply_chat_template=apply_chat_template,
            fewshot_as_multiturn=fewshot_as_multiturn,
            chat_template=getattr(lm, "apply_chat_template")
            if apply_chat_template
            else None,
            tokenizer_name=getattr(lm, "tokenizer_name", "")
            if apply_chat_template
            else "",
        )
        eval_logger.debug(
            f"Task: {task_output.task_name}; number of requests on this rank: {len(task.instances)}"
        )
        if write_out:
            print_writeout(task)
        # aggregate Instances by LM method requested to get output.
        for instance in task.instances:
            reqtype = instance.request_type
            requests[reqtype].append(instance)

        if lm.world_size > 1:
            instances_rnk = torch.tensor(len(task._instances), device=lm.device)
            gathered_item = (
                lm.accelerator.gather(instances_rnk).cpu().detach().numpy().tolist()
            )
            # "multiple_choice" task types dispatch (several) "loglikelihood" request types
            reqtype = (
                "loglikelihood"
                if task.OUTPUT_TYPE == "multiple_choice"
                else task.OUTPUT_TYPE
            )
            # compute number of pseudo-batches to pad with (FSDP/DDP require even batches among ranks)
            numpad = max(gathered_item) - gathered_item[lm.rank]
            # todo: may not account for padding in cases like SquadV2 which has multiple req types
            padding_requests[reqtype] += numpad

    ### Run LM on inputs, get all outputs ###
    # execute each type of request
    _meta_pack = []
    for reqtype, reqs in requests.items():
        eval_logger.info(f"Running {reqtype} requests")
        # # create `K` copies of each request `req` based off `K = req.repeats`
        cloned_reqs = []
        _qidx_list = np.arange(0, len(reqs)).tolist()
        _selected_qidx_list = split_func(_qidx_list, GPU_NUMBER)[GPU_ID]

        for _qidx, req in enumerate(reqs):
            if _qidx in _selected_qidx_list:
                cloned_reqs.extend([req] * req.repeats)        
        # # run requests through model
        resps = getattr(lm, reqtype)(cloned_reqs)

        _meta_pack.append(resps)

    gpu_meta_data = pickle.dumps(_meta_pack)
    return gpu_meta_data


def split_func(a, n):
    l = len(a)
    task_l = [a[i:i+int(l/n)] for i in range(0, l, int(l/n))]
    _task_l = task_l
    if len(task_l) > n:
        _task_l = _task_l[:n]
        _task_l[-1].extend(task_l[-1])
        task_l = _task_l
    return task_l

def load_checkpoint(cfg_checkpointer):
    _checkpointer = config.instantiate(
        cfg_checkpointer,
        resume_from_checkpoint=False,
    )
    checkpoint_dict = _checkpointer.load_checkpoint()
    return  checkpoint_dict

class PPLAutoModel(torch.nn.Module):
    def __init__(self, model, cfg):
        super(PPLAutoModel, self).__init__()
        self._model = model
        self._loss_fn = torch.nn.CrossEntropyLoss()
        process_cap_map = {}
        for k,v in cfg.cap.items():
            process_cap_map[k.split('_')[1]] = v
        self._model.process_cap_map = process_cap_map
        self._model.exp_tag = cfg.exp_tag
        self._model.prefix_num = cfg.prefix_num
    
    def set_cap(self, cap):
        process_cap_map = {}
        for k,v in cap.items():
            process_cap_map[k.split('_')[1]] = v
        self._model.process_cap_map = process_cap_map

    def forward(self, tokens, labels, input_pos, mask):
        logits = self._model(tokens, mask=mask, input_pos=input_pos)
        # Shift so that tokens < n predict n
        logits = logits[..., :-1, :].contiguous()
        labels = labels[..., 1:].contiguous()
        logits = logits.transpose(1, 2)
        loss = self._loss_fn(logits, labels)
        ppl = torch.exp(loss)
        return ppl


cfg = DictConfig(cfg_dict)
_model = config.instantiate(cfg.model)
cfg.tokenizer.path = cfg.tokenizer.path.replace("<native_llama_path>", cfg.native_llama_path)
_tokenizer = config.instantiate(cfg.tokenizer)
ckpt_dict = load_checkpoint(cfg.checkpointer)
model_state_dict = ckpt_dict[utils.MODEL_KEY]
_model.load_state_dict(model_state_dict, strict = False)
_model.eval()

global_ppl_model = None
global_eval_model = None

GPU_ID = 0
GPU_NUMBER = 8
DEVICE = None
app = Flask(__name__)

def __run_benchmark(cfg, task_names):
    """
    
    """
    global_eval_model.set_cap_info(cfg)
    _tasks = task_names
    _num_fewshots = {
        "winogrande":0,
        "arc_challenge":0,
        "arc_easy":0,
        "mmlu":5,
        "hellaswag":0,
    }
    try:
        lm_eval.tasks.initialize_tasks()
    except Exception:
        pass
    task_manager = TaskManager(include_path=None)
    task_dict = get_task_dict(_tasks, task_manager)
    for task_name in task_dict.keys():
        task_obj = task_dict[task_name]
        if isinstance(task_obj, tuple):
            _, task_obj = task_obj
            if task_obj is None:
                continue
        # override tasks' fewshot values to the provided num_fewshot arg value
        # except if tasks have it set to 0 manually in their configs--then we should never overwrite that
        if _num_fewshots[task_name] != 0:
            task_obj.set_config(key="num_fewshot", value=_num_fewshots[task_name])
        else:
            # if num_fewshot not provided, and the task does not define a default one, default to 0
            if (default_num_fewshot := task_obj.get_config("num_fewshot")) is None:
                task_obj.set_config(key="num_fewshot", value=0)
        # fewshot_random_seed set for tasks, even with a default num_fewshot (e.g. in the YAML file)
        task_obj.set_fewshot_seed(seed=1234)

    output_meta = evaluate(
        global_eval_model,
        task_dict,
        limit = None,
    )
    return output_meta

@app.route('/run_benchmark',methods = ['POST'])
def run_benchmark():
    set_config = request.get_data()
    if set_config is None or set_config == "":
        print('No infer_cfg input')
    set_config = json.loads(set_config)
    infer_cfg = set_config['infer_cfg']
    task_names =  set_config['task_names']
    meta_out = __run_benchmark(infer_cfg, task_names) # -> bytes
    return meta_out

with open(cfg.data_pkl, 'rb') as f:
    dump_data = pickle.load(f)
tokens_list, labels_list, input_pos_list, mask_list = \
    dump_data['tokens_list'], dump_data['labels_list'], dump_data['input_pos_list'], dump_data['mask_list']
data_len = len(tokens_list)

def __get_ppl_from_alpaca_256(cap_dict = None):
    print(f'Work on {GPU_ID}')
    sub_tokens_list, sub_labels_list, sub_input_pos_list, sub_mask_list = \
        split_func(tokens_list, GPU_NUMBER)[GPU_ID], \
        split_func(labels_list, GPU_NUMBER)[GPU_ID], \
        split_func(input_pos_list, GPU_NUMBER)[GPU_ID], \
        split_func(mask_list, GPU_NUMBER)[GPU_ID], \
        
    if cap_dict is not None:
        global_ppl_model.set_cap(cap_dict)
    
    ppls = []
    for tokens, labels, input_pos, mask in zip(sub_tokens_list, sub_labels_list, sub_input_pos_list, sub_mask_list):
        tokens, labels = tokens.to(DEVICE), labels.to(DEVICE)
        ppl = global_ppl_model(tokens, labels, input_pos, mask)
        ppls.append(ppl.item())
    out = {'ppls':ppls}
    return out

@app.route('/get_ppl_from_alpaca_256',methods = ['POST'])
def get_ppl_from_alpaca_256():
    set_config = request.get_data()
    if set_config is None or set_config == "":
        print('No cap input')
    set_config = json.loads(set_config)
    cap_dict = set_config['cap_dict']
    out = __get_ppl_from_alpaca_256(cap_dict)
    return jsonify(out)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Dist worker')
    parser.add_argument("--gpus", type=int, default = 8)
    parser.add_argument("--task_id", type=int, default = 0)
    parser.add_argument("--port", type=int, default = 8000)
    parser.add_argument("--base_url", type=str, default="0.0.0.0")
    args = parser.parse_args()
    GPU_NUMBER = args.gpus
    GPU_ID = args.task_id
    DEVICE = torch.device(f'cuda:{GPU_ID}')

    global_ppl_model = PPLAutoModel(_model, cfg).to(DEVICE)
    global_eval_model = _EvalWrapper(
            _model,
            _tokenizer,
            device = DEVICE,
            max_seq_length = 4096,
            batch_size = 1,
            dtype =utils.get_dtype("fp32"),
    )

    print('Load model over, starting service....')
    app.run(host=args.base_url,port=args.port)


