# process_cap_map = { # expected process capacity.
#     "17": 0.3683,
#     "19": 0.2768,
#     "21": 0.2057,
#     "23": 0.1631,
#     "25": 0.1241,
#     "27": 0.1228,
#     "29": 0.1391,
# }

# process_cap_map = { # expected process capacity.
#     "9": 0.4,
#     "11": 0.4,
#     "13": 0.4,
#     "15": 0.4,
#     "17": 0.3683,
#     "19": 0.2768,
#     "21": 0.2057,
#     "23": 0.1631,
#     "25": 0.1241,
#     "27": 0.1228,
#     "29": 0.1391,
# }


# process_cap_map = { # expected process capacity.
#     "16": 0.8679,
#     "17": 0.7049,
#     "18": 0.6086,
#     "19": 0.5297,
#     "20": 0.5332,
#     "21": 0.3936,
#     "22": 0.3728,
#     "23": 0.3121,
#     "24": 0.1,
#     "25": 0.1,
#     "26": 0.1,
#     "27": 0.1,
#     "28": 0.1,
#     "29": 0.1,
#     "30": 0.4734,
# }


# process_cap_map = { # expected process capacity.
#     "16": 0.8679,
#     "17": 0.7049,
#     "18": 0.6086,
#     "19": 0.5297,
#     "20": 0.5332,
#     "21": 0.1,
#     "22": 0.1,
#     "23": 0.1,
#     "24": 0.1,
#     "25": 0.1,
#     "26": 0.1,
#     "27": 0.1,
#     "28": 0.1,
#     "29": 0.1,
#     "30": 0.4734,
# }

# process_cap_map = {
#     "layer_16": 0.5223,
#     "layer_17": 0.4242,
#     "layer_18": 0.3663,
#     "layer_19": 0.3188,
#     "layer_20": 0.3209,
#     "layer_21": 0.2369,
#     "layer_22": 0.2243,
#     "layer_23": 0.1878,
#     "layer_24": 0.1701,
#     "layer_25": 0.1429,
#     "layer_26": 0.1575,
#     "layer_27": 0.1414,
#     "layer_28": 0.1509,
#     "layer_29": 0.1602,
#     "layer_30": 0.2849,
# }

# process_cap_map = {
#     "layer_16": 0.3016,
#     "layer_17": 0.2450,
#     "layer_18": 0.2115,
#     "layer_19": 0.1841,
#     "layer_20": 0.1853,
#     "layer_21": 0.1368,
#     "layer_22": 0.1296,
#     "layer_23": 0.1085,
#     "layer_24": 0.0982,
#     "layer_25": 0.0825,
#     "layer_26": 0.0910,
#     "layer_27": 0.0816,
#     "layer_28": 0.0871,
#     "layer_29": 0.0925,
#     "layer_30": 0.1645,
# }



# process_cap_map = {
#     "layer_9": 0.9,
#     "layer_10": 0.7,
#     "layer_11": 0.7,
#     "layer_12": 0.7,
#     "layer_13": 0.7,
#     "layer_14": 0.7,
#     "layer_15": 0.7,
#     "layer_16": 0.7,
#     "layer_17": 0.7,
#     "layer_18": 0.7,
#     "layer_19": 0.7,
#     "layer_20": 0.4,
#     "layer_21": 0.4,
#     "layer_22": 0.4,
#     "layer_23": 0.4,
#     "layer_24": 0.4,
#     "layer_25": 0.4,
#     "layer_26": 0.4,
#     "layer_27": 0.4,
#     "layer_28": 0.4,
#     "layer_29": 0.4,
#     "layer_30": 0.5,
# }



process_cap_map = {
    "layer_1": 0.9,
    "layer_2": 0.9,
    "layer_3": 0.9,
    "layer_4": 0.9,
    "layer_5": 0.9,
    "layer_6": 0.9,
    "layer_7": 0.9,
    "layer_8": 0.9,
    "layer_9": 0.9,
    "layer_10": 0.7,
    "layer_11": 0.7,
    "layer_12": 0.7,
    "layer_13": 0.7,
    "layer_14": 0.7,
    "layer_15": 0.7,
    "layer_16": 0.7,
    "layer_17": 0.7,
    "layer_18": 0.7,
    "layer_19": 0.7,
    "layer_20": 0.6,
    "layer_21": 0.6,
    "layer_22": 0.6,
    "layer_23": 0.6,
    "layer_24": 0.4,
    "layer_25": 0.4,
    "layer_26": 0.4,
    "layer_27": 0.4,
    "layer_28": 0.4,
    "layer_29": 0.4,
    "layer_30": 0.5,
}

for k,v in process_cap_map.items():
    print(k + ": " + str(v))

all_cap = 0
for k, v in process_cap_map.items():
    all_cap += v
ratio = 1 - (32 - len(process_cap_map) + all_cap) / 32
print(ratio)

