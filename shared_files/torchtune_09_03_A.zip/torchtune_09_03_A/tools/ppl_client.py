import requests
import json
import numpy as np
import torch
from multiprocess import Pool

def api_agent(msg):
    gpu_id, send_data = msg
    api_url = f"http://127.0.0.1:800{gpu_id}/get_ppl_from_alpaca_256"
    res = requests.post(url = api_url, json=send_data)
    response = json.loads(res.text)
    return response

def evaluate_ppl(cap_dict): # RPC to multi-GPUs
    tasks_data = {
                "infer_cfg":
                {
                    "exp_tag": EXP_TAG,
                    "prefix_num": PREFIX_NUM,
                    "postfix_num": POSTFIX_NUM,
                    "cap": cap_dict           
                }
            }
    with Pool(GPU_NUMBER) as pool:
        final_results = []
        sync_results = pool.map(api_agent, [(gpu_id, tasks_data) for gpu_id in range(GPU_NUMBER)]) # slower, but more stable than async
        for res in sync_results:
            final_results.extend(res['ppls'])
    mean_ppl = np.mean(final_results)
    return mean_ppl

EXP_TAG = 'position'
PREFIX_NUM = 1
POSTFIX_NUM = 1
GPU_NUMBER = 8

cap_dict =  {
    "layer_16": 0.7403,
    "layer_17": 0.6013,
    "layer_18": 0.5192,
    "layer_19": 0.4519,
    "layer_20": 0.4548,
    "layer_21": 0.3357,
    "layer_22": 0.3180,
    "layer_23": 0.2662,
    "layer_24": 0.2411,
    "layer_25": 0.2026,
    "layer_26": 0.2233,
    "layer_27": 0.2043,
    "layer_28": 0.2137,
    "layer_29": 0.2270,
    "layer_30": 0.4038,
}


if __name__ == '__main__':
    print(evaluate_ppl(cap_dict))