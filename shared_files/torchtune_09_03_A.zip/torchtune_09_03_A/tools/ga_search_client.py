import requests
import json
from multiprocessing import Process, Pool
import numpy as np
from sko.GA import GA
import torch

# for debug.
# cap_data = {
#     "cap_dict": {"layer_1": 0.1, "layer_2": 0.9, "layer_3": 0.9,"layer_4": 0.9,"layer_5": 0.9,"layer_6": 0.9,"layer_7": 0.9,"layer_8": 0.9,"layer_9": 0.9,"layer_10": 0.7,"layer_11": 0.7,"layer_12": 0.7,"layer_13": 0.7,"layer_14": 0.7,"layer_15": 0.7,"layer_16": 0.7,"layer_17": 0.7,"layer_18": 0.7,"layer_19": 0.7,"layer_20": 0.6,"layer_21": 0.6,"layer_22": 0.6,"layer_23": 0.6,"layer_24": 0.4,"layer_25": 0.4,"layer_26": 0.4,"layer_27": 0.4,"layer_28": 0.4,"layer_29": 0.4,"layer_30": 0.5}
# }

# api_url = f"http://127.0.0.1:8002/call"
# res = requests.post(url = api_url, json=cap_data)
# response = json.loads(res.text)
# print(response)

ALL_LAYER_NUM = 32
EXPECTED_SR = 0.3
GPU_NUMBER = 8
PARAM_MAPPER = {0: 'layer_1', 1: 'layer_2', 2: 'layer_3', 3: 'layer_4', 4: 'layer_5', 5: 'layer_6', 6: 'layer_7', 7: 'layer_8', 8: 'layer_9', 9: 'layer_10', 10: 'layer_11', 11: 'layer_12', 12: 'layer_13', 13: 'layer_14', 14: 'layer_15', 15: 'layer_16', 16: 'layer_17', 17: 'layer_18', 18: 'layer_19', 19: 'layer_20', 20: 'layer_21', 21: 'layer_22', 22: 'layer_23', 23: 'layer_24', 24: 'layer_25', 25: 'layer_26', 26: 'layer_27', 27: 'layer_28', 28: 'layer_29', 29: 'layer_30'}

def cal_SR(process_cap_map):
    print(process_cap_map)
    all_cap = 0
    for k, v in process_cap_map.items():
        all_cap += v
    ratio = 1 - (32 - len(process_cap_map) + all_cap) / 32
    return ratio

def api_agent(msg):
    gpu_id, cap_data = msg
    api_url = f"http://127.0.0.1:800{gpu_id}/call"
    res = requests.post(url = api_url, json=cap_data)
    response = json.loads(res.text)
    return response

def evaluate_ppl(_cap): # RPC to multi-GPUs
# def evaluate_ppl(ga_instance, _cap, solution_idx): # RPC to multi-GPUs
    cap_engergy = (((1 - EXPECTED_SR) * ALL_LAYER_NUM) + _cap.shape[0] - ALL_LAYER_NUM)
    _cap = torch.softmax(torch.from_numpy(_cap), dim = 0).numpy()
    _cap = _cap * cap_engergy
    _cap = np.clip(_cap, 0, 1)
    cap_data = {'cap_dict':{}}
    for parma_id, c in enumerate(_cap): # _cap: [dims,]
        cap_data["cap_dict"][PARAM_MAPPER[parma_id]] = c
    print(cal_SR(cap_data["cap_dict"]))
    with Pool(GPU_NUMBER) as pool:
        # async_results = [pool.apply_async(api_agent, (gpu_id, cap_data, )) for gpu_id in range(GPU_NUMBER)]
        final_results = []
        sync_results = pool.map(api_agent, [(gpu_id, cap_data, ) for gpu_id in range(GPU_NUMBER)])
        for res in sync_results:
            final_results.extend(res['ppls'])
    mean_ppl = np.mean(final_results)
    return -1 * mean_ppl

nga = GA(
    func = evaluate_ppl,
    n_dim = 30, 
    size_pop = 100, # *6.73s -> 1, 
    max_iter = 5, 
    lb = 0, 
    ub = 1,
    prob_mut = 0.1,
)
best_params, best_ppl = nga.run()
print('best_x:', best_params, '\n', 'best_ppl:', -best_ppl)


# import pygad
# import numpy

# """
# Given the following function:
#     y = f(w1:w6) = w1x1 + w2x2 + w3x3 + w4x4 + w5x5 + 6wx6
#     where (x1,x2,x3,x4,x5,x6)=(4,-2,3.5,5,-11,-4.7) and y=44
# What are the best values for the 6 weights (w1 to w6)? We are going to use the genetic algorithm to optimize this function.
# """

# function_inputs = [4, -2, 3.5, 5,-11,-4.7] # Function inputs.
# desired_output = 44 # Function output.

# def fitness_func():
#     # Calculating the fitness value of each solution in the current population.
#     # The fitness function calulates the sum of products between each input and its corresponding weight.
#     print(solution.shape)
#     output = numpy.sum(solution*function_inputs)
#     fitness = 1.0 / numpy.abs(output - desired_output)
#     return fitness

# fitness_function = fitness_func

# num_generations = 100 # Number of generations.
# num_parents_mating = 7 # Number of solutions to be selected as parents in the mating pool.

# # To prepare the initial population, there are 2 ways:
# # 1) Prepare it yourself and pass it to the initial_population parameter. This way is useful when the user wants to start the genetic algorithm with a custom initial population.
# # 2) Assign valid integer values to the sol_per_pop and num_genes parameters. If the initial_population parameter exists, then the sol_per_pop and num_genes parameters are useless.
# sol_per_pop = 50 # Number of solutions in the population.
# num_genes = len(function_inputs)

# last_fitness = 0
# def callback_generation(ga_instance):
#     global last_fitness
#     print(f"Generation = {ga_instance.generations_completed}")
#     print(f"Fitness    = {ga_instance.best_solution()[1]}")
#     print(f"Change     = {ga_instance.best_solution()[1] - last_fitness}")
#     last_fitness = ga_instance.best_solution()[1]

# # Creating an instance of the GA class inside the ga module. Some parameters are initialized within the constructor.
# ga_instance = pygad.GA(num_generations=num_generations,
#                        num_parents_mating=num_parents_mating, 
#                        initial_population = None,
#                        fitness_func=fitness_function,
#                        sol_per_pop=sol_per_pop, 
#                        num_genes=num_genes,
#                        on_generation=callback_generation)

# # Running the GA to optimize the parameters of the function.
# ga_instance.run()

# # After the generations complete, some plots are showed that summarize the how the outputs/fitenss values evolve over generations.
# # ga_instance.plot_fitness()

# # Returning the details of the best solution.
# solution, solution_fitness, solution_idx = ga_instance.best_solution()
# print(f"Parameters of the best solution : {solution}")
# print(f"Fitness value of the best solution = {solution_fitness}")
# print(f"Index of the best solution : {solution_idx}")

# prediction = numpy.sum(numpy.array(function_inputs)*solution)
# print(f"Predicted output based on the best solution : {prediction}")

# if ga_instance.best_solution_generation != -1:
#     print(f"Best fitness value reached after {ga_instance.best_solution_generation} generations.")