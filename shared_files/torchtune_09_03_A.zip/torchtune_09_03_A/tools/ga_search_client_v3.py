
import json
import torch.utils
import torch.utils.data
from torchtune import config, modules, utils
from omegaconf import DictConfig
import lightning as L
import torch
import pickle
import requests
import json
import argparse
import lm_eval
from lm_eval.models.huggingface import HFLM
from lm_eval.tasks import get_task_dict, TaskManager
from lm_eval.utils import make_table
from typing import Any, Dict, List, Tuple, Union
from torchtune.modules.tokenizers import ModelTokenizer
from torch.nn.utils.rnn import pad_sequence
import itertools
import json
import logging
import random
import time
from collections import defaultdict
from typing import TYPE_CHECKING, List, Optional, Union
import lm_eval.api.metrics
import lm_eval.api.registry
import lm_eval.models
from lm_eval.caching.cache import delete_cache
from lm_eval.evaluator_utils import (
    consolidate_results,
    get_sample_size,
    get_task_list,
    prepare_print_tasks,
    print_writeout,
    run_task_tests,
)
from lm_eval.loggers import EvaluationTracker
from lm_eval.loggers.utils import add_env_info, add_tokenizer_info, get_git_commit_hash
from lm_eval.tasks import TaskManager, get_task_dict
from lm_eval.utils import (
    eval_logger,
    handle_non_serializable,
    hash_string,
    positional_deprecated,
    simple_parse_args_string,
)
if TYPE_CHECKING:
    from lm_eval.api.model import LM
    from lm_eval.tasks import Task
import numpy as np
from multiprocessing import Process, Pool
import pygad
import re

def api_agent(msg):
    gpu_id, send_data = msg
    api_url = f"http://127.0.0.1:800{gpu_id}/run_benchmark"
    res = requests.post(url = api_url, json=send_data)
    card_meta_decoded = pickle.loads(res.content)
    results = (gpu_id, card_meta_decoded[0])
    return results

@positional_deprecated
def evaluate(
    task_dict,
    cap_dict = None,
    limit: Optional[int] = None,
    cache_requests: bool = False,
    rewrite_requests_cache: bool = False,
    bootstrap_iters: Optional[int] = 100000,
    write_out: bool = False,
    log_samples: bool = True,
    system_instruction: Optional[str] = None,
    apply_chat_template: bool = False,
    fewshot_as_multiturn: bool = False,
    verbosity: str = "INFO",
):
    eval_logger.setLevel(getattr(logging, f"{verbosity}"))

    # tracks all Instances/requests a model must generate output on.
    requests = defaultdict(list)
    # stores the amount to pad out reqs per req. type so that
    # number of fwd passes per distributed rank is equal
    padding_requests = defaultdict(int)

    # get lists of group hierarchy and each type of request
    task_hierarchy, eval_tasks = get_task_list(task_dict)
    if not log_samples:
        if not all(
            "bypass" not in getattr(task_output.task, "_metric_fn_list", {}).keys()
            for task_output in eval_tasks
        ):
            raise ValueError("log_samples must be True for 'bypass' metric-only tasks")
    for task_output in eval_tasks:
        task: Task = task_output.task
        limit = get_sample_size(task, limit)
        task.build_all_requests(
            limit=limit,
            rank=0,
            world_size=1,
            cache_requests=cache_requests,
            rewrite_requests_cache=rewrite_requests_cache,
            system_instruction=system_instruction,
            apply_chat_template=apply_chat_template,
            fewshot_as_multiturn=fewshot_as_multiturn,
            chat_template=None,
            tokenizer_name="",
        )
        eval_logger.debug(
            f"Task: {task_output.task_name}; number of requests on this rank: {len(task.instances)}"
        )
        if write_out:
            print_writeout(task)
        # aggregate Instances by LM method requested to get output.
        for instance in task.instances:
            reqtype = instance.request_type
            requests[reqtype].append(instance)

        

    ### Run LM on inputs, get all outputs ###
    # execute each type of request
    for reqtype, reqs in requests.items():
        eval_logger.info(f"Running {reqtype} requests on {GPU_NUMBER} GPUs, please wait...")
        # # create `K` copies of each request `req` based off `K = req.repeats`
        cloned_reqs = []
        for req in reqs:
            cloned_reqs.extend([req] * req.repeats)

        tasks_data = {
            "task_names": TASK_NAMES,
            "infer_cfg":
            {
                "exp_tag": EXP_TAG,
                "prefix_num": PREFIX_NUM,
                "postfix_num": POSTFIX_NUM,
                "cap": cap_dict           
            }
        }

        with Pool(GPU_NUMBER) as pool:
            final_results = []
            sync_results = pool.map(api_agent, [(gpu_id, tasks_data) for gpu_id in range(GPU_NUMBER)]) # slower, but more stable than async
            sync_results = sorted(sync_results, key=lambda x: x[0]) # sorted by gpuid
            for re in sync_results:
                final_results.extend(re[1])
        resps = final_results
        # # run requests through model
        # resps = getattr(lm, reqtype)(cloned_reqs)
        
        # put responses from model into a list of length K for each request.
        for x, req in zip(resps, cloned_reqs):
            req.resps.append(x)


    # with open('temp_results.pkl', 'wb') as _f:
    #     pickle.dump(_meta_pack, _f)

    RANK = 0
    WORLD_SIZE = 1
    ### Postprocess outputs ###
    # TODO: del model here, maybe (idea: allow user to specify device of e.g. reward model separately)
    for task_output in eval_tasks:
        task = task_output.task
        task.apply_filters()

        ### Collect values of metrics on all datapoints ###
        # # unpack results and sort back in order and return control to Task
        # TODO: make it possible to use a different metric per filter
        # Pre-process task.instances to group by doc_id
        instances_by_doc_id = defaultdict(list)
        for instance in task.instances:
            instances_by_doc_id[instance.doc_id].append(instance)
        # Sort instances within each group
        for instances in instances_by_doc_id.values():
            instances.sort(key=lambda x: x.idx)
        # iterate over different filters used
        for filter_key in task.instances[0].filtered_resps.keys():
            doc_iterator = task.doc_iterator(
                rank=RANK, limit=limit, world_size=WORLD_SIZE
            )
            for doc_id, doc in doc_iterator:
                requests = instances_by_doc_id[doc_id]
                metrics = task.process_results(
                    doc, [req.filtered_resps[filter_key] for req in requests]
                )
                if log_samples:
                    target = task.doc_to_target(doc)
                    example = {
                        "doc_id": doc_id,
                        "doc": doc,
                        "target": target,
                        "arguments": [req.args for req in requests],
                        "resps": [req.resps for req in requests],
                        "filtered_resps": [
                            req.filtered_resps[filter_key] for req in requests
                        ],
                        "doc_hash": hash_string(
                            json.dumps(
                                requests[0].doc,
                                indent=2,
                                default=handle_non_serializable,
                                ensure_ascii=False,
                            )
                        ),
                        "prompt_hash": hash_string(requests[0].arguments[0]),
                        "target_hash": hash_string(str(target)),
                    }
                    example.update(metrics)
                    task_output.logged_samples.append(example)
                for metric, value in metrics.items():
                    task_output.sample_metrics[(metric, filter_key)].append(value)

    if WORLD_SIZE > 1:
        # if multigpu, then gather data across all ranks to rank 0
        # first gather logged samples across all ranks
        for task_output in eval_tasks:
            if log_samples:
                # for task_name, task_samples in list(samples.items()):
                full_samples = [None] * WORLD_SIZE if RANK == 0 else None
                torch.distributed.gather_object(
                    obj=task_output.logged_samples,
                    object_gather_list=full_samples,
                    dst=0,
                )

                if RANK == 0:
                    task_output.logged_samples = list(
                        itertools.chain.from_iterable(full_samples)
                    )

            # then collect metrics across all ranks
            for metrics in task_output.sample_metrics:
                metric_list = [None] * WORLD_SIZE if RANK == 0 else None
                torch.distributed.gather_object(
                    obj=task_output.sample_metrics[metrics],
                    object_gather_list=metric_list,
                    dst=0,
                )
                if RANK == 0:
                    task_output.sample_metrics[metrics] = list(
                        itertools.chain.from_iterable(metric_list)
                    )

    if RANK == 0:
        ### Aggregate results over all datapoints ###
        # aggregate results ; run bootstrap CIs
        for task_output in eval_tasks:
            task_output.calculate_aggregate_metric(bootstrap_iters=bootstrap_iters)
        (
            results,
            samples,
            configs,
            versions,
            num_fewshot,
            higher_is_better,
        ) = consolidate_results(eval_tasks)

        ### Calculate group metrics ###
        if bool(results):
            for group, task_list in reversed(task_hierarchy.items()):
                if len(task_list) == 0:
                    # task_hierarchy entries are either
                    # `group_name: [subtask1, subtask2, ...]`
                    # or `task_name: []`.
                    # we only want to operate on groups here.
                    continue

                # collect all higher_is_better values for metrics
                # in the group's subtasks.
                # TODO: clean this up ; unify with the below metric_list loop?
                _higher_is_better = {}
                for task in task_list:
                    for m, h in higher_is_better[task].items():
                        if m not in _higher_is_better.keys():
                            _higher_is_better[m] = h
                    if (
                        m in _higher_is_better
                        and _higher_is_better[m] is not None
                        and _higher_is_better[m] != h
                    ):
                        eval_logger.warning(
                            f"Higher_is_better values for metric {m} in group {group} are not consistent. Defaulting to None."
                        )
                        _higher_is_better[m] = None
                higher_is_better[group] = _higher_is_better

                # collect all metric keys used by a subtask in the group.
                metric_list = list(
                    {
                        key
                        for task in task_list
                        for key in results[task].keys()
                        if "_stderr" not in key and key not in ["alias", "samples"]
                    }
                )
                for metric in metric_list:
                    stderr = "_stderr,".join(metric.split(","))

                    # gather metrics, sizes, and stderrs from subtasks
                    metrics = [
                        results[task][metric]
                        for task in task_list
                        if metric in results[task]
                    ]  # TODO: copy?
                    stderrs = [
                        results[task][stderr]
                        for task in task_list
                        if stderr in results[task]
                    ]
                    sizes = [
                        results[task]["samples"]
                        for task in task_list
                        if metric in results[task]
                    ]

                    # compute group's pooled metric and stderr
                    results[group][metric] = (
                        lm_eval.api.metrics.aggregate_subtask_metrics(metrics, sizes)
                    )
                    # TODO: calculate grouped metric using aggregation fn
                    if "N/A" in stderrs:
                        results[group][stderr] = "N/A"
                    else:
                        results[group][stderr] = (
                            lm_eval.api.metrics.pooled_sample_stderr(stderrs, sizes)
                        )
                        # TODO: allow GroupConfigs to choose which variance formula is used, for back-compatibility
                        # To use the old (likely incorrect) variance formula, comment out the above and uncomment this line:
                        # results[group][stderr] = lm_eval.api.metrics.combined_sample_stderr(stderrs, sizes, metrics=metrics)

                    results[group]["samples"] = sum(sizes)

        results_agg = defaultdict(dict)
        groups_agg = defaultdict(dict)
        all_tasks_list = list(task_hierarchy.keys())
        while True:
            add_tasks_list = list(k for k in results_agg.keys())
            left_tasks_list = sorted(list(set(all_tasks_list) - set(add_tasks_list)))
            if len(left_tasks_list) == 0:
                break

            _task_hierarchy = {
                k: v for k, v in task_hierarchy.items() if k in left_tasks_list
            }
            _results_agg, _groups_agg = prepare_print_tasks(_task_hierarchy, results)

            results_agg = {**results_agg, **_results_agg}
            groups_agg = {**groups_agg, **_groups_agg}

        for group_name, task_list in task_hierarchy.items():
            if task_list:
                num_fewshot[group_name] = num_fewshot[
                    task_list[0]
                ]  # TODO: validate this

        results_dict = {
            "results": dict(results_agg.items()),
            **({"groups": dict(groups_agg.items())} if bool(groups_agg) else {}),
            "group_subtasks": dict(reversed(task_hierarchy.items())),
            "configs": dict(sorted(configs.items())),
            "versions": dict(sorted(versions.items())),
            "n-shot": dict(sorted(num_fewshot.items())),
            "higher_is_better": dict(sorted(higher_is_better.items())),
            "n-samples": {
                task_output.task_name: {
                    "original": len(task_output.task.eval_docs),
                    "effective": min(
                        limit if limit else len(task_output.task.eval_docs),
                        len(task_output.task.eval_docs),
                    ),
                }
                for task_output in eval_tasks
            },
        }
        if log_samples:
            results_dict["samples"] = dict(samples)

        return results_dict

    else:
        return None



def eval_benchmark(cap_dict):
    _tasks = TASK_NAMES
    _num_fewshots = {
        "winogrande":0,
        "arc_challenge":0,
        "arc_easy":0,
        "mmlu":5,
        "hellaswag":0,
    }
    try:
        lm_eval.tasks.initialize_tasks()
    except Exception:
        pass
    task_manager = TaskManager(include_path=None)
    task_dict = get_task_dict(_tasks, task_manager)
    for task_name in task_dict.keys():
        task_obj = task_dict[task_name]
        if isinstance(task_obj, tuple):
            _, task_obj = task_obj
            if task_obj is None:
                continue
        # override tasks' fewshot values to the provided num_fewshot arg value
        # except if tasks have it set to 0 manually in their configs--then we should never overwrite that
        if _num_fewshots[task_name] != 0:
            task_obj.set_config(key="num_fewshot", value=_num_fewshots[task_name])
        else:
            # if num_fewshot not provided, and the task does not define a default one, default to 0
            if (default_num_fewshot := task_obj.get_config("num_fewshot")) is None:
                task_obj.set_config(key="num_fewshot", value=0)
        # fewshot_random_seed set for tasks, even with a default num_fewshot (e.g. in the YAML file)
        task_obj.set_fewshot_seed(seed=1234)

    output_final = evaluate(
        task_dict,
        cap_dict = cap_dict,
        limit = None,
    )
    # format_final = make_table(output_final) -> # view table
    acc = round(output_final['results'][TASK_NAMES[0]]['acc,none'], 4) # only work on winogrande
    return acc


def cap_decode(params, print_cap = False):
    cap_energy = (((1 - EXPECTED_SR) * ALL_LAYER_NUM) + params.shape[0] - ALL_LAYER_NUM)
    _cap = torch.softmax(torch.from_numpy(params), dim = 0).numpy()
    _cap = _cap * cap_energy
    _cap = np.clip(_cap, 0, 1)
    cap_data = {}
    for parma_id, c in enumerate(_cap): # _cap: [dims,]
        cap_data[PARAM_MAPPER[parma_id]] = c
    if print_cap:
        for k, v in cap_data.items():
            print(k + ": " + "{:.4f}".format(v))
    print(cal_SR(cap_data))
    return cap_data


def cal_SR(process_cap_map):
    all_cap = 0
    for k, v in process_cap_map.items():
        all_cap += v
    ratio = 1 - (ALL_LAYER_NUM - len(process_cap_map) + all_cap) / ALL_LAYER_NUM
    return ratio

def get_initial_population(scores, p, sol_per_pop):
    _scores = torch.from_numpy(scores)
    init_params = torch.repeat_interleave(_scores.unsqueeze(0), sol_per_pop, dim = 0).numpy()
    perturbation = np.random.uniform(-p, p, size=(sol_per_pop, scores.shape[0]))
    init_params = init_params + perturbation
    init_params[0] = _scores
    return init_params

def get_initial_population_v2(init_scores, p, sol_per_pop, init_modes = 'E|S|1S'):
    init_scores = torch.from_numpy(init_scores)
    # init_params = torch.repeat_interleave(_scores.unsqueeze(0), sol_per_pop, dim = 0).numpy()
    init_modes = init_modes.split('|')
    assert sol_per_pop % len(init_modes) == 0, "must be divied by the init mode's length"
    sub_len = int(sol_per_pop / len(init_modes))
    all_scores = []
    for init_mode in init_modes:
        if 'E' == init_mode:
            _scores = torch.ones([init_scores.shape[0]], dtype = torch.float32)
            print(cap_decode(_scores.numpy()))
            _scores = torch.repeat_interleave(_scores.unsqueeze(0), sub_len, dim = 0)
            all_scores.append(_scores)
        elif 'S' == init_mode:
            print(cap_decode(init_scores.numpy()))
            _scores = torch.repeat_interleave(init_scores.unsqueeze(0), sub_len, dim = 0)
            all_scores.append(_scores)
        elif '1S' == init_mode:
            _scores = init_scores
            cap_energy = (((1 - EXPECTED_SR) * ALL_LAYER_NUM) + init_scores.shape[0] - ALL_LAYER_NUM)
            half_mod_layer_len = int(init_scores.shape[0]/2)
            _sub_scores = _scores[half_mod_layer_len:]
            _sub_scores = torch.relu(_sub_scores)
            _sub_scores = _sub_scores * (cap_energy - half_mod_layer_len)
            print(_sub_scores)
            _scores[half_mod_layer_len:] = _sub_scores
            _scores[:half_mod_layer_len] = 1.
            print(cap_decode(_scores.numpy()))
            _scores = torch.repeat_interleave(_scores.unsqueeze(0), sub_len, dim = 0)
            all_scores.append(_scores)
    all_scores = torch.cat(all_scores, dim = 0).numpy()     
    return all_scores1


def callback_generation(ga_instance):
    global last_fitness
    print(f"##### Callback info: Generation={ga_instance.generations_completed}\nBest acc={ga_instance.best_solution()[1]}\nSolution={cap_decode(ga_instance.best_solution()[0])}")
    last_fitness = ga_instance.best_solution()[1]

global_cache = {}

def fitness_func(ga_instance, _cap, solution_idx):
    global global_cache
    cap_dict = cap_decode(_cap)
    cache_key = json.dumps(cap_dict)
    if cache_key in global_cache.keys():
        acc = global_cache[cache_key] 
    else:
        acc = eval_benchmark(cap_dict) # RPC to multi-GPUs
    print(cap_dict, acc)
    return acc

TASK_NAMES = ["winogrande"]
GPU_NUMBER = 6
PREFIX_NUM = 1
POSTFIX_NUM = 1
EXP_TAG = "position"

ALL_LAYER_NUM = 32
EXPECTED_SR = 0.4
PARAM_MAPPER = {0: 'layer_1', 1: 'layer_2', 2: 'layer_3', 3: 'layer_4', 4: 'layer_5', 5: 'layer_6', 6: 'layer_7', 7: 'layer_8', 8: 'layer_9', 9: 'layer_10', 10: 'layer_11', 11: 'layer_12', 12: 'layer_13', 13: 'layer_14', 14: 'layer_15', 15: 'layer_16', 16: 'layer_17', 17: 'layer_18', 18: 'layer_19', 19: 'layer_20', 20: 'layer_21', 21: 'layer_22', 22: 'layer_23', 23: 'layer_24', 24: 'layer_25', 25: 'layer_26', 26: 'layer_27', 27: 'layer_28', 28: 'layer_29', 29: 'layer_30'}
block_sim_score_1_30 = [0.7073, 0.8521, 0.8532, 0.8436, 0.8512, 0.8609, 0.863, 0.8738, 0.879, 0.8862, 0.8985, 0.8993, 0.8983, 0.9007, 0.9008, 0.8999, 0.9187, 0.9298, 0.9389, 0.9385, 0.9546, 0.957, 0.964, 0.9674, 0.9726, 0.9698, 0.9729, 0.9711, 0.9693, 0.9454] # Function inputs.
bi_score = 1 - np.array(block_sim_score_1_30)
layer_weights = bi_score

get_initial_population_v2(bi_score, None, 6)
print('init cap:', cap_decode(layer_weights), cal_SR( cap_decode(layer_weights)))



init_perturbation = 0.05
sol_per_pop = 10 # Number of solutions in the population.
num_generations = 100 # Number of generations.
num_parents_mating = 3 # Number of solutions to be selected as parents in the mating pool.
num_genes = len(layer_weights)
last_fitness = -1e-8 # NOTE, this is a global var.

if __name__ == "__main__":
    # debug.
    # cap_dict = {"layer_1": 0.9, "layer_2": 0.9, "layer_3": 0.9,"layer_4": 0.9,"layer_5": 0.9,"layer_6": 0.9,"layer_7": 0.9,"layer_8": 0.9,"layer_9": 0.9,"layer_10": 0.7,"layer_11": 0.7,"layer_12": 0.7,"layer_13": 0.7,"layer_14": 0.7,"layer_15": 0.7,"layer_16": 0.7,"layer_17": 0.7,"layer_18": 0.7,"layer_19": 0.7,"layer_20": 0.6,"layer_21": 0.6,"layer_22": 0.6,"layer_23": 0.6,"layer_24": 0.4,"layer_25": 0.4,"layer_26": 0.4,"layer_27": 0.4,"layer_28": 0.4,"layer_29": 0.4,"layer_30": 0.5} 
    # eval_benchmark(cap_dict)

    # Creating an instance of the GA class inside the ga module. Some parameters are initialized within the constructor.
    ga_instance = pygad.GA(num_generations = num_generations,
                        num_parents_mating = num_parents_mating, 
                        initial_population = get_initial_population(layer_weights, p = init_perturbation, sol_per_pop = sol_per_pop),
                        fitness_func = fitness_func,
                        sol_per_pop=sol_per_pop,
                        num_genes=num_genes,
                        on_generation = callback_generation,
                        init_range_high = 0.05,
                        init_range_low = -0.05,)

    # Running the GA to optimize the parameters of the function.
    ga_instance.run()
    solution, solution_fitness, solution_idx = ga_instance.best_solution()
    print(f"Parameters of the best solution : {cap_decode(solution)}")
    print(f"Fitness value of the best solution = {solution_fitness}")
    print(f"Index of the best solution : {solution_idx}")
    if ga_instance.best_solution_generation != -1:
        print(f"Best fitness value reached after {ga_instance.best_solution_generation} generations.")
    filename = 'search_genetic' # The filename to which the instance is saved. The name is without extension.
    ga_instance.save(filename=filename)

    # loaded_ga_instance = pygad.load(filename=filename)
    # loaded_ga_instance.plot_fitness()

