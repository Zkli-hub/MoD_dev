
import json
import torch.utils
import torch.utils.data
from torchtune import config, modules, utils
from omegaconf import DictConfig
import lightning as L
import torch
import pickle
from flask import Flask,request,jsonify
import json
import argparse

cfg_dict ={
    "data_pkl": "dump_data.pkl",
    "model":{"_component_": "torchtune.models.llama2.llama2_7b_mod"},
    "native_llama_path":  "./llama-2-7b-hf",
    "tokenizer":{
        "_component_": "torchtune.models.llama2.llama2_tokenizer",
        "path": "<native_llama_path>/tokenizer.model"
    },
    "checkpointer":{
        "_component_": "torchtune.utils.FullModelHFCheckpointer",
        "checkpoint_dir": "./llama-2-7b-hf",
        "checkpoint_files": [
            "pytorch_model-00001-of-00002.bin",
            "pytorch_model-00002-of-00002.bin"
        ],
        "adapter_checkpoint": None,
        "recipe_checkpoint": None,
        "output_dir": "",
        "model_type": "LLAMA2"
    },
    "exp_tag": "position",
    "prefix_num": 1,
    "cap": {"layer_1": 0.9, "layer_2": 0.9, "layer_3": 0.9,"layer_4": 0.9,"layer_5": 0.9,"layer_6": 0.9,"layer_7": 0.9,"layer_8": 0.9,"layer_9": 0.9,"layer_10": 0.7,"layer_11": 0.7,"layer_12": 0.7,"layer_13": 0.7,"layer_14": 0.7,"layer_15": 0.7,"layer_16": 0.7,"layer_17": 0.7,"layer_18": 0.7,"layer_19": 0.7,"layer_20": 0.6,"layer_21": 0.6,"layer_22": 0.6,"layer_23": 0.6,"layer_24": 0.4,"layer_25": 0.4,"layer_26": 0.4,"layer_27": 0.4,"layer_28": 0.4,"layer_29": 0.4,"layer_30": 0.5}
    # NOTE, A dumpy cap setting, if called from clients, this would be covered.
}

def load_checkpoint(cfg_checkpointer):
    _checkpointer = config.instantiate(
        cfg_checkpointer,
        resume_from_checkpoint=False,
    )
    checkpoint_dict = _checkpointer.load_checkpoint()
    return  checkpoint_dict

class WrapAutoModel(torch.nn.Module):
    def __init__(self, model, cfg):
        super(WrapAutoModel, self).__init__()
        self._model = model
        self._loss_fn = torch.nn.CrossEntropyLoss()
        process_cap_map = {}
        for k,v in cfg.cap.items():
            process_cap_map[k.split('_')[1]] = v
        self._model.process_cap_map = process_cap_map
        self._model.exp_tag = cfg.exp_tag
        self._model.prefix_num = cfg.prefix_num
    
    def set_cap(self, cap):
        process_cap_map = {}
        for k,v in cap.items():
            process_cap_map[k.split('_')[1]] = v
        self._model.process_cap_map = process_cap_map

    def forward(self, tokens, labels, input_pos, mask):
        logits = self._model(tokens, mask=mask, input_pos=input_pos)
        # Shift so that tokens < n predict n
        logits = logits[..., :-1, :].contiguous()
        labels = labels[..., 1:].contiguous()
        logits = logits.transpose(1, 2)
        loss = self._loss_fn(logits, labels)
        ppl = torch.exp(loss)
        return ppl

cfg = DictConfig(cfg_dict)
_model = config.instantiate(cfg.model)
cfg.tokenizer.path = cfg.tokenizer.path.replace("<native_llama_path>", cfg.native_llama_path)
_tokenizer = config.instantiate(cfg.tokenizer)
ckpt_dict = load_checkpoint(cfg.checkpointer)
model_state_dict = ckpt_dict[utils.MODEL_KEY]
_model.load_state_dict(model_state_dict, strict = False)
_model.eval()
global_model = WrapAutoModel(_model, cfg)
GPU_ID = 0
GPU_NUMBER = 8
DEVICE = None
app = Flask(__name__)

with open(cfg.data_pkl, 'rb') as f:
    dump_data = pickle.load(f)
tokens_list, labels_list, input_pos_list, mask_list = \
    dump_data['tokens_list'], dump_data['labels_list'], dump_data['input_pos_list'], dump_data['mask_list']
data_len = len(tokens_list)

def run(cap_dict = None):
    print(f'Work on {GPU_ID}')
    split_func = lambda a, l, n : [a[i:i+int(l/n)] for i in range(0, l, int(l/n))]
    sub_tokens_list, sub_labels_list, sub_input_pos_list, sub_mask_list = \
        split_func(tokens_list, len(tokens_list), GPU_NUMBER)[GPU_ID], \
        split_func(labels_list, len(labels_list), GPU_NUMBER)[GPU_ID], \
        split_func(input_pos_list, len(input_pos_list), GPU_NUMBER)[GPU_ID], \
        split_func(mask_list, len(mask_list), GPU_NUMBER)[GPU_ID], \
        
    if cap_dict is not None:
        global_model.set_cap(cap_dict)
    
    ppls = []
    for tokens, labels, input_pos, mask in zip(sub_tokens_list, sub_labels_list, sub_input_pos_list, sub_mask_list):
        tokens, labels = tokens.to(DEVICE), labels.to(DEVICE)
        ppl = global_model(tokens, labels, input_pos, mask)
        ppls.append(ppl.item())
    out = {'ppls':ppls}
    return out

@app.route('/call',methods = ['POST'])
def call():
    set_config = request.get_data()
    if set_config is None or set_config == "":
        print('No cap input')
    set_config = json.loads(set_config)
    cap_dict = set_config['cap_dict']
    out = run(cap_dict)
    return jsonify(out)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Dist worker')
    parser.add_argument("--gpus", type=int, default = 8)
    parser.add_argument("--task_id", type=int, default = 0)
    parser.add_argument("--port", type=int, default = 8000)
    parser.add_argument("--base_url", type=str, default="0.0.0.0")
    args = parser.parse_args()
    GPU_NUMBER = args.gpus
    GPU_ID = args.task_id
    DEVICE = torch.device(f'cuda:{GPU_ID}')
    global_model = global_model.to(DEVICE)
    print('Load model over, starting service....')
    app.run(host=args.base_url,port=args.port)


