
import json
import torch.utils
import torch.utils.data
from torchtune import config, modules, utils
from omegaconf import DictConfig
import lightning as L
import torch
import pickle
import requests
import json
import argparse
import lm_eval
from lm_eval.models.huggingface import HFLM
from lm_eval.tasks import get_task_dict, TaskManager
from lm_eval.utils import make_table
from typing import Any, Dict, List, Tuple, Union
from torchtune.modules.tokenizers import ModelTokenizer
from torch.nn.utils.rnn import pad_sequence
import itertools
import json
import logging
import random
import time
from collections import defaultdict
from typing import TYPE_CHECKING, List, Optional, Union
import lm_eval.api.metrics
import lm_eval.api.registry
import lm_eval.models
from lm_eval.caching.cache import delete_cache
from lm_eval.evaluator_utils import (
    consolidate_results,
    get_sample_size,
    get_task_list,
    prepare_print_tasks,
    print_writeout,
    run_task_tests,
)
from lm_eval.loggers import EvaluationTracker
from lm_eval.loggers.utils import add_env_info, add_tokenizer_info, get_git_commit_hash
from lm_eval.tasks import TaskManager, get_task_dict
from lm_eval.utils import (
    eval_logger,
    handle_non_serializable,
    hash_string,
    positional_deprecated,
    simple_parse_args_string,
)
if TYPE_CHECKING:
    from lm_eval.api.model import LM
    from lm_eval.tasks import Task
import numpy as np
from multiprocessing import Process, Pool
import pygad
import re
from tqdm import trange

def api_agent(msg):
    gpu_id, send_data = msg
    api_url = f"http://127.0.0.1:800{gpu_id}/run_benchmark"
    res = requests.post(url = api_url, json=send_data)
    card_meta_decoded = pickle.loads(res.content)
    results = (gpu_id, card_meta_decoded[0])
    return results

@positional_deprecated
def evaluate(
    task_dict,
    cap_dict = None,
    limit: Optional[int] = None,
    cache_requests: bool = False,
    rewrite_requests_cache: bool = False,
    bootstrap_iters: Optional[int] = 100000,
    write_out: bool = False,
    log_samples: bool = True,
    system_instruction: Optional[str] = None,
    apply_chat_template: bool = False,
    fewshot_as_multiturn: bool = False,
    verbosity: str = "INFO",
):
    eval_logger.setLevel(getattr(logging, f"{verbosity}"))

    # tracks all Instances/requests a model must generate output on.
    requests = defaultdict(list)
    # stores the amount to pad out reqs per req. type so that
    # number of fwd passes per distributed rank is equal
    padding_requests = defaultdict(int)

    # get lists of group hierarchy and each type of request
    task_hierarchy, eval_tasks = get_task_list(task_dict)
    if not log_samples:
        if not all(
            "bypass" not in getattr(task_output.task, "_metric_fn_list", {}).keys()
            for task_output in eval_tasks
        ):
            raise ValueError("log_samples must be True for 'bypass' metric-only tasks")
    for task_output in eval_tasks:
        task: Task = task_output.task
        limit = get_sample_size(task, limit)
        task.build_all_requests(
            limit=limit,
            rank=0,
            world_size=1,
            cache_requests=cache_requests,
            rewrite_requests_cache=rewrite_requests_cache,
            system_instruction=system_instruction,
            apply_chat_template=apply_chat_template,
            fewshot_as_multiturn=fewshot_as_multiturn,
            chat_template=None,
            tokenizer_name="",
        )
        eval_logger.debug(
            f"Task: {task_output.task_name}; number of requests on this rank: {len(task.instances)}"
        )
        if write_out:
            print_writeout(task)
        # aggregate Instances by LM method requested to get output.
        for instance in task.instances:
            reqtype = instance.request_type
            requests[reqtype].append(instance)

        

    ### Run LM on inputs, get all outputs ###
    # execute each type of request
    for reqtype, reqs in requests.items():
        eval_logger.info(f"Running {reqtype} requests on {GPU_NUMBER} GPUs, please wait...")
        # # create `K` copies of each request `req` based off `K = req.repeats`
        cloned_reqs = []
        for req in reqs:
            cloned_reqs.extend([req] * req.repeats)

        tasks_data = {
            "task_names": TASK_NAMES,
            "infer_cfg":
            {
                "exp_tag": EXP_TAG,
                "prefix_num": PREFIX_NUM,
                "postfix_num": POSTFIX_NUM,
                "cap": cap_dict           
            }
        }

        with Pool(GPU_NUMBER) as pool:
            final_results = []
            sync_results = pool.map(api_agent, [(gpu_id, tasks_data) for gpu_id in range(GPU_NUMBER)]) # slower, but more stable than async
            sync_results = sorted(sync_results, key=lambda x: x[0]) # sorted by gpuid
            for re in sync_results:
                final_results.extend(re[1])
        resps = final_results
        # # run requests through model
        # resps = getattr(lm, reqtype)(cloned_reqs)
        
        # put responses from model into a list of length K for each request.
        for x, req in zip(resps, cloned_reqs):
            req.resps.append(x)


    # with open('temp_results.pkl', 'wb') as _f:
    #     pickle.dump(_meta_pack, _f)

    RANK = 0
    WORLD_SIZE = 1
    ### Postprocess outputs ###
    # TODO: del model here, maybe (idea: allow user to specify device of e.g. reward model separately)
    for task_output in eval_tasks:
        task = task_output.task
        task.apply_filters()

        ### Collect values of metrics on all datapoints ###
        # # unpack results and sort back in order and return control to Task
        # TODO: make it possible to use a different metric per filter
        # Pre-process task.instances to group by doc_id
        instances_by_doc_id = defaultdict(list)
        for instance in task.instances:
            instances_by_doc_id[instance.doc_id].append(instance)
        # Sort instances within each group
        for instances in instances_by_doc_id.values():
            instances.sort(key=lambda x: x.idx)
        # iterate over different filters used
        for filter_key in task.instances[0].filtered_resps.keys():
            doc_iterator = task.doc_iterator(
                rank=RANK, limit=limit, world_size=WORLD_SIZE
            )
            for doc_id, doc in doc_iterator:
                requests = instances_by_doc_id[doc_id]
                metrics = task.process_results(
                    doc, [req.filtered_resps[filter_key] for req in requests]
                )
                if log_samples:
                    target = task.doc_to_target(doc)
                    example = {
                        "doc_id": doc_id,
                        "doc": doc,
                        "target": target,
                        "arguments": [req.args for req in requests],
                        "resps": [req.resps for req in requests],
                        "filtered_resps": [
                            req.filtered_resps[filter_key] for req in requests
                        ],
                        "doc_hash": hash_string(
                            json.dumps(
                                requests[0].doc,
                                indent=2,
                                default=handle_non_serializable,
                                ensure_ascii=False,
                            )
                        ),
                        "prompt_hash": hash_string(requests[0].arguments[0]),
                        "target_hash": hash_string(str(target)),
                    }
                    example.update(metrics)
                    task_output.logged_samples.append(example)
                for metric, value in metrics.items():
                    task_output.sample_metrics[(metric, filter_key)].append(value)

    if WORLD_SIZE > 1:
        # if multigpu, then gather data across all ranks to rank 0
        # first gather logged samples across all ranks
        for task_output in eval_tasks:
            if log_samples:
                # for task_name, task_samples in list(samples.items()):
                full_samples = [None] * WORLD_SIZE if RANK == 0 else None
                torch.distributed.gather_object(
                    obj=task_output.logged_samples,
                    object_gather_list=full_samples,
                    dst=0,
                )

                if RANK == 0:
                    task_output.logged_samples = list(
                        itertools.chain.from_iterable(full_samples)
                    )

            # then collect metrics across all ranks
            for metrics in task_output.sample_metrics:
                metric_list = [None] * WORLD_SIZE if RANK == 0 else None
                torch.distributed.gather_object(
                    obj=task_output.sample_metrics[metrics],
                    object_gather_list=metric_list,
                    dst=0,
                )
                if RANK == 0:
                    task_output.sample_metrics[metrics] = list(
                        itertools.chain.from_iterable(metric_list)
                    )

    if RANK == 0:
        ### Aggregate results over all datapoints ###
        # aggregate results ; run bootstrap CIs
        for task_output in eval_tasks:
            task_output.calculate_aggregate_metric(bootstrap_iters=bootstrap_iters)
        (
            results,
            samples,
            configs,
            versions,
            num_fewshot,
            higher_is_better,
        ) = consolidate_results(eval_tasks)

        ### Calculate group metrics ###
        if bool(results):
            for group, task_list in reversed(task_hierarchy.items()):
                if len(task_list) == 0:
                    # task_hierarchy entries are either
                    # `group_name: [subtask1, subtask2, ...]`
                    # or `task_name: []`.
                    # we only want to operate on groups here.
                    continue

                # collect all higher_is_better values for metrics
                # in the group's subtasks.
                # TODO: clean this up ; unify with the below metric_list loop?
                _higher_is_better = {}
                for task in task_list:
                    for m, h in higher_is_better[task].items():
                        if m not in _higher_is_better.keys():
                            _higher_is_better[m] = h
                    if (
                        m in _higher_is_better
                        and _higher_is_better[m] is not None
                        and _higher_is_better[m] != h
                    ):
                        eval_logger.warning(
                            f"Higher_is_better values for metric {m} in group {group} are not consistent. Defaulting to None."
                        )
                        _higher_is_better[m] = None
                higher_is_better[group] = _higher_is_better

                # collect all metric keys used by a subtask in the group.
                metric_list = list(
                    {
                        key
                        for task in task_list
                        for key in results[task].keys()
                        if "_stderr" not in key and key not in ["alias", "samples"]
                    }
                )
                for metric in metric_list:
                    stderr = "_stderr,".join(metric.split(","))

                    # gather metrics, sizes, and stderrs from subtasks
                    metrics = [
                        results[task][metric]
                        for task in task_list
                        if metric in results[task]
                    ]  # TODO: copy?
                    stderrs = [
                        results[task][stderr]
                        for task in task_list
                        if stderr in results[task]
                    ]
                    sizes = [
                        results[task]["samples"]
                        for task in task_list
                        if metric in results[task]
                    ]

                    # compute group's pooled metric and stderr
                    results[group][metric] = (
                        lm_eval.api.metrics.aggregate_subtask_metrics(metrics, sizes)
                    )
                    # TODO: calculate grouped metric using aggregation fn
                    if "N/A" in stderrs:
                        results[group][stderr] = "N/A"
                    else:
                        results[group][stderr] = (
                            lm_eval.api.metrics.pooled_sample_stderr(stderrs, sizes)
                        )
                        # TODO: allow GroupConfigs to choose which variance formula is used, for back-compatibility
                        # To use the old (likely incorrect) variance formula, comment out the above and uncomment this line:
                        # results[group][stderr] = lm_eval.api.metrics.combined_sample_stderr(stderrs, sizes, metrics=metrics)

                    results[group]["samples"] = sum(sizes)

        results_agg = defaultdict(dict)
        groups_agg = defaultdict(dict)
        all_tasks_list = list(task_hierarchy.keys())
        while True:
            add_tasks_list = list(k for k in results_agg.keys())
            left_tasks_list = sorted(list(set(all_tasks_list) - set(add_tasks_list)))
            if len(left_tasks_list) == 0:
                break

            _task_hierarchy = {
                k: v for k, v in task_hierarchy.items() if k in left_tasks_list
            }
            _results_agg, _groups_agg = prepare_print_tasks(_task_hierarchy, results)

            results_agg = {**results_agg, **_results_agg}
            groups_agg = {**groups_agg, **_groups_agg}

        for group_name, task_list in task_hierarchy.items():
            if task_list:
                num_fewshot[group_name] = num_fewshot[
                    task_list[0]
                ]  # TODO: validate this

        results_dict = {
            "results": dict(results_agg.items()),
            **({"groups": dict(groups_agg.items())} if bool(groups_agg) else {}),
            "group_subtasks": dict(reversed(task_hierarchy.items())),
            "configs": dict(sorted(configs.items())),
            "versions": dict(sorted(versions.items())),
            "n-shot": dict(sorted(num_fewshot.items())),
            "higher_is_better": dict(sorted(higher_is_better.items())),
            "n-samples": {
                task_output.task_name: {
                    "original": len(task_output.task.eval_docs),
                    "effective": min(
                        limit if limit else len(task_output.task.eval_docs),
                        len(task_output.task.eval_docs),
                    ),
                }
                for task_output in eval_tasks
            },
        }
        if log_samples:
            results_dict["samples"] = dict(samples)

        return results_dict

    else:
        return None



def eval_benchmark(cap_dict):
    _tasks = TASK_NAMES
    _num_fewshots = 0
    try:
        lm_eval.tasks.initialize_tasks()
    except Exception:
        pass
    task_manager = TaskManager(include_path=None)
    task_dict = get_task_dict(_tasks, task_manager)
    for task_name in task_dict.keys():
        task_obj = task_dict[task_name]
        if isinstance(task_obj, tuple):
            _, task_obj = task_obj
            if task_obj is None:
                continue
        # override tasks' fewshot values to the provided num_fewshot arg value
        # except if tasks have it set to 0 manually in their configs--then we should never overwrite that
        if _num_fewshots != 0:
            task_obj.set_config(key="num_fewshot", value=_num_fewshots)
        else:
            # if num_fewshot not provided, and the task does not define a default one, default to 0
            if (default_num_fewshot := task_obj.get_config("num_fewshot")) is None:
                task_obj.set_config(key="num_fewshot", value=0)
        # fewshot_random_seed set for tasks, even with a default num_fewshot (e.g. in the YAML file)
        task_obj.set_fewshot_seed(seed=1234)

    output_final = evaluate(
        task_dict,
        cap_dict = cap_dict,
        limit = None,
    )
    # format_final = make_table(output_final) -> # view table
    if TASK_NAMES[0] == 'winogrande':
        acc = round(output_final['results'][TASK_NAMES[0]]['acc,none'], 4)

    elif TASK_NAMES[0] == 'openbookqa':
        acc = round(output_final['results'][TASK_NAMES[0]]['acc_norm,none'], 4)

    return acc


def cap_decode(_cap, print_cap = False):
    _cap = np.clip(_cap, 0.01, 0.9999)
    cap_data = {}
    for parma_id, c in enumerate(_cap): # _cap: [dims,]
        cap_data[PARAM_MAPPER[parma_id]] = c
    if print_cap:
        for k, v in cap_data.items():
            print(k + ": " + "{:.4f}".format(v))
    print('SR:', cal_SR(cap_data))
    return cap_data


def cal_SR(process_cap_map):
    all_cap = 0
    for k, v in process_cap_map.items():
        all_cap += v
    ratio = 1 - (ALL_LAYER_NUM - len(process_cap_map) + all_cap) / ALL_LAYER_NUM
    return ratio

def get_initial_population(scores, p, sol_per_pop):
    _scores = torch.from_numpy(scores)
    init_params = torch.repeat_interleave(_scores.unsqueeze(0), sol_per_pop, dim = 0).numpy()
    perturbation = np.random.uniform(-p, p, size=(sol_per_pop, scores.shape[0]))
    init_params = init_params + perturbation
    init_params[0] = _scores
    return init_params

global_cache = {}
def fitness_func(_cap):
    global global_cache
    cap_dict = cap_decode(_cap)
    cache_key = json.dumps(cap_dict)
    print(cap_dict)
    if cache_key in global_cache.keys():
        acc = global_cache[cache_key] 
    else:
        acc = eval_benchmark(cap_dict) # RPC to multi-GPUs
    print('acc:', acc)
    return acc


def select(population):
    # Evaluate each candidate and select the best ones
    scores = [fitness_func(p) for p in population]
    selected = np.argsort(scores)[-len(population)//2:]
    best_id = np.argmax(scores)
    print('Best in curr selection:', cap_decode(population[best_id]), 'acc:', scores[best_id])
    return [population[i] for i in selected]

def genetic_algorithm_sparsity(capacity_maps, population_size=20, generations=50, mutation_rate = 0.1, init_p = 0.05, mutation_p = 0.05, mutation_max_times = 5):
    positions = list(capacity_maps.keys())
    capacities = np.array(list(capacity_maps.values()))
    sparsity_sum = len(positions) * (1 - EXPECTED_SR * ALL_LAYER_NUM / len(positions))

    # Initialize population
    population = [capacities + np.random.uniform(-init_p, init_p, size=len(positions)) for _ in range(population_size - 1)]
    population.append(capacities)
    population = [p * (sparsity_sum / p.sum()) for p in population]
    
    for _ in trange(generations):
        # Selection
        parents = select(population)
        # Crossover
        offspring = []
        for i in range(0, len(parents), 2):
            if i+1 < len(parents):
                crossover_point = np.random.randint(1, len(positions)-1)
                child1 = np.concatenate((parents[i][:crossover_point], parents[i+1][crossover_point:]))
                child2 = np.concatenate((parents[i+1][:crossover_point], parents[i][crossover_point:]))
                offspring.append(child1)
                offspring.append(child2)
        
        # Mutation
        for child in offspring:
            if np.random.rand() < mutation_rate:  # Mutation rate
                mutation_times = random.randint(1, mutation_max_times)
                print(f'Happening {mutation_times} mutations')
                for _ in range(mutation_times):
                    mutation_point = random.randint(len(positions))
                    child[mutation_point] += random.uniform(-mutation_p, mutation_p)
                    child *= (sparsity_sum / child.sum())  # Re-normalize
        
        # Create the new population
        population = parents + offspring
    
    # Evaluate final population and return the best configuration
    best_sparsity = max(population, key=lambda p: fitness_func(p))
    best_accuracy = fitness_func(dict(zip(positions, best_sparsity)))
    
    return dict(zip(positions, best_sparsity)), best_accuracy


TASK_NAMES = ["winogrande"] # openbookqa
GPU_NUMBER = 8
PREFIX_NUM = 0
POSTFIX_NUM = 1
EXP_TAG = "hybrid_feats" # position

ALL_LAYER_NUM = 32
EXPECTED_SR = 0.4
PARAM_MAPPER = {0: 'layer_1', 1: 'layer_2', 2: 'layer_3', 3: 'layer_4', 4: 'layer_5', 5: 'layer_6', 6: 'layer_7', 7: 'layer_8', 8: 'layer_9', 9: 'layer_10', 10: 'layer_11', 11: 'layer_12', 12: 'layer_13', 13: 'layer_14', 14: 'layer_15', 15: 'layer_16', 16: 'layer_17', 17: 'layer_18', 18: 'layer_19', 19: 'layer_20', 20: 'layer_21', 21: 'layer_22', 22: 'layer_23', 23: 'layer_24', 24: 'layer_25', 25: 'layer_26', 26: 'layer_27', 27: 'layer_28', 28: 'layer_29', 29: 'layer_30'}

# cap init from BI score.
# init_cap_dict = {'layer_1': 1.0, 'layer_2': 0.9209615523857791, 'layer_3': 0.9141119397581636, 'layer_4': 0.9738903772355363, 'layer_5': 0.926565780899283, 'layer_6': 0.8661646513648537, 'layer_7': 0.8530881181666784, 'layer_8': 0.7858373760046335, 'layer_9': 0.7534573890377232, 'layer_10': 0.7086235609296935, 'layer_11': 0.6320324379118093, 'layer_12': 0.6270509014553614, 'layer_13': 0.6332778220259211, 'layer_14': 0.6183332126565783, 'layer_15': 0.6177105205995216, 'layer_16': 0.6233147491130254, 'layer_17': 0.5062486423865036, 'layer_18': 0.43712982405329087, 'layer_19': 0.38046484686119764, 'layer_20': 0.3829556150894213, 'layer_21': 0.2827021939034101, 'layer_22': 0.2677575845340672, 'layer_23': 0.22416914054014925, 'layer_24': 0.20299761060024585, 'layer_25': 0.17061762363333555, 'layer_26': 0.18805300123090285, 'layer_27': 0.16874954746216786, 'layer_28': 0.17995800448917545, 'layer_29': 0.19116646151618238, 'layer_30': 0.3399898631525593}

# cap init from custom.
init_cap_dict = {
    'layer_1': 1.0, 
    'layer_2': 1.0, 
    'layer_3': 1.0, 
    'layer_4': 1.0, 
    'layer_5': 1.0, 
    'layer_6': 1.0, 
    'layer_7': 1.0, 
    "layer_8": 0.8088,
    "layer_9": 0.7754,
    "layer_10": 0.7293,
    "layer_11": 0.6505,
    "layer_12": 0.6453,
    "layer_13": 0.6517,
    "layer_14": 0.6364,
    "layer_15": 0.6357,
    "layer_16": 0.6415,
    "layer_17": 0.5210,
    "layer_18": 0.4499,
    "layer_19": 0.3916,
    "layer_20": 0.3941,
    "layer_21": 0.2909,
    "layer_22": 0.2756,
    "layer_23": 0.2307,
    "layer_24": 0.2089,
    "layer_25": 0.1756,
    "layer_26": 0.1935,
    "layer_27": 0.1737,
    "layer_28": 0.1852,
    "layer_29": 0.1967,
    "layer_30": 0.3499
}

population_size = 6 # Number of solutions in the population.
generations = 100 # Number of generations.
init_p = 0.3 # perturtation of initial process
mutation_rate = 0.5 # prob to mutation
mutation_p = 0.3 # perturtation of mutation
mutation_max_times = 15 # random choose from (1,max times) of mutation

if __name__ == "__main__":
    results = genetic_algorithm_sparsity(init_cap_dict, population_size = population_size, generations = generations, init_p = init_p, mutation_p=mutation_p, mutation_rate = mutation_rate, mutation_max_times = mutation_max_times)
    print(results)