import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

DARW_DIS_LOSS = True

log_path = 'exps/lora_mod/logs/log_1723560791.txt'

def parser(return_dis_loss = True):
    with open(log_path, 'r') as f:
        lines = f.readlines()
    item_loss_data = []
    for line in lines:
        if 'dis_loss: [' in line:
            data = float(line.split('dis_loss: [')[1].split(']')[0])
            item_loss_data.append(data)
    return item_loss_data

def moving_average(data, window_size):
    return [sum(data[i:i+window_size]) / window_size for i in range(len(data) - window_size + 1)]


dis_loss = parser()
dis_loss = moving_average(dis_loss, 5)
steps = list(range(1, len(dis_loss) + 1))

# Create a DataFrame for easier plotting with Seaborn
data = pd.DataFrame({
    'Steps': steps,
    'Loss': dis_loss,
})
# Set the style
sns.set(style="whitegrid")
# Create the plot
plt.figure(figsize=(10, 6))
sns.scatterplot(x='Steps', y='Loss', data=data, color='#FF69B4', s=50, label='Distillation Loss')
sns.lineplot(x='Steps', y='Loss', data=data, color='#FF69B4')
# Add title and labels
plt.title('Loss Trend Over Steps', fontsize=14, fontweight='bold')
plt.xlabel('Steps', fontsize=12)
plt.ylabel('Loss', fontsize=12)

# Add legend
plt.legend()
plt.savefig('loss_figure.png')
