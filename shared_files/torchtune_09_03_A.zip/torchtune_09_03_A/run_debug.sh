# export HIP_VISIBLE_DEVICES=7
# echo "Process is working on: $HIP_VISIBLE_DEVICES"

# Scheme A: Only router training in Mixture-of-Depth

# Llama2
CUDA_VISIBLE_DEVICES=0 tune run ./scripts/router_only_train.py --config ./configs/llama2_7B/7B_llama2_router_mod.yaml

# Qwen2
#CUDA_VISIBLE_DEVICES=1 tune run ./scripts/router_only_train.py --config ./configs/qwen1.5_7B/7B_qwen1.5_router_mod.yaml

# Scheme B: Update router and LoRA parameters
# tune run ./scripts/lora_train_dev.py --config ./configs/llama2_7B/7B_llama2_lora_mod.yaml

