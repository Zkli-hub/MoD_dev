#!/bin/bash

# WORKER_SCRIPT="./tools/ppl_dist_worker.py"
WORKER_SCRIPT="./tools/infer_dist_worker.py"

ps aux | grep $WORKER_SCRIPT |  awk '{print $2}' | xargs kill -9