import torch.utils
import torch.utils.data
from torchtune import config, modules, utils
from omegaconf import DictConfig
import torch
import pickle
import json
import numpy as np
import seaborn as sns
from matplotlib import pyplot as plt

GPU_ID = 0

cfg_dict ={
    "data_pkl": "/home/yifei/zkli/MoD/torchtune_09_03_A/view_token_feat.pkl",
    # ==============================
    # LLAMA2-7B
    # ==============================
    # "model":{"_component_": "torchtune.models.llama2.llama2_7b"},
    # "tokenizer":{
    #     "_component_": "torchtune.models.llama2.llama2_tokenizer",
    #     "path": "/home/yifei/zkli/MoD/llama/7b-hf/tokenizer.model"
    # },
    # "checkpointer":{
    #     "_component_": "torchtune.utils.FullModelHFCheckpointer",
    #     "checkpoint_dir": "/home/yifei/zkli/MoD/llama/7b-hf",
    #     "checkpoint_files": [
    #         "pytorch_model-00001-of-00003.bin",
    #         "pytorch_model-00002-of-00003.bin",
    #         "pytorch_model-00003-of-00003.bin"
    #     ],
    #     "adapter_checkpoint": None,
    #     "recipe_checkpoint": None,
    #     "output_dir": "",
    #     "model_type": "LLAMA2"
    "model":{"_component_": "torchtune.models.qwen2.qwen1_5_7b"},
    "native_llama_path":  "",
    "tokenizer":{
        "_component_": "torchtune.models.qwen2.qwen2_tokenizer",
        "path": "/home/yifei/zkli/MoD/torchtune_09_03_A/qwen/vocab.json",
        "merges_file" : "/home/yifei/zkli/MoD/torchtune_09_03_A/qwen/merges.txt"
    },
    "checkpointer":{
        "_component_": "torchtune.utils.FullModelHFCheckpointer",
        
        "checkpoint_dir": "/home/yifei/zkli/MoD/torchtune_09_03_A/qwen",
        "checkpoint_files": [
            "model-00001-of-00004.safetensors",
            "model-00002-of-00004.safetensors",
            "model-00003-of-00004.safetensors",
            "model-00004-of-00004.safetensors",
        ],
        "adapter_checkpoint": None,
        "recipe_checkpoint": None,
        "output_dir": "",
        "model_type": "QWEN2"
    },

    # ============================== #
    # QWEN-1.5-7B
    # ============================== # 
    # "model":{"_component_": "torchtune.models.qwen2.qwen1_5_7b"},
    # "native_llama_path":  "",
    # "tokenizer":{
    #     "_component_": "torchtune.models.qwen2.qwen2_tokenizer",
    #     "path": "./qwen-1.5-7b-hf/vocab.json",
    #     "merges_file" : "./qwen-1.5-7b-hf/merges.txt"
    # },
    # "checkpointer":{
    #     "_component_": "torchtune.utils.FullModelHFCheckpointer",
        
    #     "checkpoint_dir": "./qwen-1.5-7b-hf",
    #     "checkpoint_files": [
    #         "model-00001-of-00004.safetensors",
    #         "model-00002-of-00004.safetensors",
    #         "model-00003-of-00004.safetensors",
    #         "model-00004-of-00004.safetensors",
    #     ],
    #     "adapter_checkpoint": None,
    #     "recipe_checkpoint": None,
    #     "output_dir": "",
    #     "model_type": "QWEN2"
    # },
}


def load_checkpoint(cfg_checkpointer):
    _checkpointer = config.instantiate(
        cfg_checkpointer,
        resume_from_checkpoint=False,
    )
    checkpoint_dict = _checkpointer.load_checkpoint()
    return  checkpoint_dict

class AutoModel(torch.nn.Module):
    def __init__(self, model, ):
        super(AutoModel, self).__init__()
        self._model = model
        self._loss_fn = torch.nn.CrossEntropyLoss()
    
    def set_cap_info(self, cfg):
        process_cap_map = {}
        for k,v in cfg['cap'].items():
            process_cap_map[k.split('_')[1]] = v
        self._model.process_cap_map = process_cap_map
        self._model.exp_tag = cfg['exp_tag']
        self._model.prefix_num = cfg['prefix_num']
        self._model.postfix_num = cfg['postfix_num']

    def forward(self, tokens, labels):
        logits = self._model(tokens, mask=None, input_pos=None)
        # Shift so that tokens < n predict n
        logits = logits[..., :-1, :].contiguous()
        labels = labels[..., 1:].contiguous()
        logits = logits.transpose(1, 2)
        loss = self._loss_fn(logits, labels)
        ppl = torch.exp(loss)
        return ppl


cfg = DictConfig(cfg_dict)
_model = config.instantiate(cfg.model)
_tokenizer = config.instantiate(cfg.tokenizer)
ckpt_dict = load_checkpoint(cfg.checkpointer)
model_state_dict = ckpt_dict[utils.MODEL_KEY]
_model.load_state_dict(model_state_dict, strict = False)
_model.eval()



DEVICE = None
with open(cfg.data_pkl, 'rb') as f:
    dump_data = pickle.load(f)
tokens_list, labels_list = dump_data['data'][0], dump_data['data'][1]
data_len = len(tokens_list)

if __name__ == "__main__":
    DEVICE = torch.device(f'cuda:{GPU_ID}')
    global_model = AutoModel(_model).to(DEVICE)

    with torch.no_grad():
        for idx, (tokens, labels) in enumerate(zip(tokens_list, labels_list)):
            tokens, labels = tokens.to(DEVICE), labels.to(DEVICE)
            global_model(tokens, labels)
            # if idx == 0: break

# bi_scores_logger
_d = [None for _ in range(len(global_model._model.bi_scores_logger))]
for k, v in global_model._model.bi_scores_logger.items():
    _d[k] = torch.stack(v, dim = 0)
_d = torch.stack(_d, dim = 0)

sim_heat_map = torch.mean(_d, dim = 1)
sim_heat_map = sim_heat_map.cpu().detach().numpy()

# Assuming sim_heat_map is the array containing token similarity values
total_tokens = sim_heat_map.size  # Total number of tokens (32 * 64 in this case)

# Condition 1: Ratio of tokens with similarity > 0.9
high_similarity_tokens = (sim_heat_map > 0.8).sum()  # Count of tokens with similarity > 0.9
high_similarity_ratio = high_similarity_tokens / total_tokens  # Ratio

# Condition 2: Ratio of tokens with similarity < 0.5
low_similarity_tokens = (sim_heat_map < 0.8).sum()  # Count of tokens with similarity < 0.5
low_similarity_ratio = low_similarity_tokens / total_tokens  # Ratio

# Print the results
print(f"Ratio of tokens with similarity > 0.9: {high_similarity_ratio:.2%}")
print(f"Ratio of tokens with similarity < 0.5: {low_similarity_ratio:.2%}")

# Convert sim_heat_map back to a PyTorch tensor before using torch.cat
sim_heat_map_tensor = torch.tensor(sim_heat_map)

# First 3 and last 3 rows (i.e., first and last 3 layers)
first_last_three_rows = torch.cat((sim_heat_map_tensor[:3], sim_heat_map_tensor[-3:]), dim=0)
remaining_rows = sim_heat_map_tensor[3:-3]

# (1) In the first and last 3 rows, calculate the ratio of tokens with similarity < 0.5
low_similarity_first_last = (first_last_three_rows < 0.8).sum()
total_first_last_tokens = first_last_three_rows.numel()  # Total number of tokens
low_similarity_first_last_ratio = low_similarity_first_last / total_first_last_tokens

# (2) In the other rows, calculate the ratio of tokens with similarity > 0.9
high_similarity_remaining = (remaining_rows > 0.8).sum()
total_remaining_tokens = remaining_rows.numel()  # Total number of tokens
high_similarity_remaining_ratio = high_similarity_remaining / total_remaining_tokens

# Print the results
print(f"Ratio of tokens with similarity < 0.5 in the first and last 3 layers: {low_similarity_first_last_ratio:.2%}")
print(f"Ratio of tokens with similarity > 0.9 in the middle layers: {high_similarity_remaining_ratio:.2%}")


# sns.heatmap(sim_heat_map)
# plt.savefig("heatmap.png", dpi=300, transparent=True)
sns.heatmap(sim_heat_map, cmap='Reds')  # Reverse the 'coolwarm' colormap
plt.savefig("heatmap.png", dpi=300, transparent=True)
