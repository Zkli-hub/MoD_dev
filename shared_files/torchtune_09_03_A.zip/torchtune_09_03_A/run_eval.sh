export HIP_VISIBLE_DEVICES=3
echo eval

# LLAMA2-7B
# tune run ./scripts/eval.py --config ./configs/llama2_7B/7B_llama2_eval.yaml

# LLAMA3-8B
# tune run ./scripts/eval.py --config ./configs/llama3_8B/8B_llama3_eval.yaml

# QWEN1.5-7B
tune run ./scripts/eval.py --config ./configs/qwen1.5_7B/7B_qwen1.5_eval.yaml

# QWEN2-7B
# tune run ./scripts/eval.py --config ./configs/qwen2_7B/7B_qwen2_eval.yaml

