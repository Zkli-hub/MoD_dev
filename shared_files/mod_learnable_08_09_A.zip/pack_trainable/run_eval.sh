export HIP_VISIBLE_DEVICES=6
echo debug
tune run eleuther_eval --config ./7B_eval_mod.yaml