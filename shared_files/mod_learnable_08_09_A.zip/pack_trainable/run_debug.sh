export HIP_VISIBLE_DEVICES=7
#gpu02: ID5=Node7;ID4=Node6
#tune run full_finetune_single_device --config ./7B_full.yaml
tune run full_finetune_single_device --config ./7B_full_mod.yaml