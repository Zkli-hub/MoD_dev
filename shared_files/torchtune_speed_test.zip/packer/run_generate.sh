export HIP_VISIBLE_DEVICES=7
echo "Process is working on: $HIP_VISIBLE_DEVICES"

# Llama2-7b
tune run ./recipes/generate.py --config ./recipes/configs/generation.yaml