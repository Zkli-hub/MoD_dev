secs = []
with open('times.txt', 'r') as f:
    datas = f.readlines()
    for data in datas:
        sec = float(data)
        secs.append(sec)
import numpy as np

secs = np.array(secs)
mean_time = np.mean(secs)

print(mean_time)