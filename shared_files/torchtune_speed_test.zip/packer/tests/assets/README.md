# Details on the assets in this folder

## `m.model`

**Description**:
**Creation**:
**Usage**:


## `tiny_fair_checkpoint.pt`

**Description**:
**Creation**:
**Usage**:

## `tiny_llama2_checkpoint.pt`

**Description**:
**Creation**:
**Usage**:

## `tiny_state_dict_with_one_key.pt`

**Description**:
**Creation**:
**Usage**:
