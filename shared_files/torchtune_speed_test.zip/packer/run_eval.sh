export HIP_VISIBLE_DEVICES=6
echo "Process is working on: $HIP_VISIBLE_DEVICES"

# Llama2-7b
tune run ./recipes/eleuther_eval.py --config ./recipes/configs/eleuther_evaluation.yaml