export HIP_VISIBLE_DEVICES=0
echo "Process is working on: $HIP_VISIBLE_DEVICES"

# Llama2-7b
tune run ./recipes/speed_test.py --config ./recipes/configs/speed_test.yaml