export HIP_VISIBLE_DEVICES=7

# Scheme A: Only router training in Mixture-of-Depth
# tune run ./scripts/router_only_train.py --config ./configs/llama2_7B/7B_llama2_router_mod.yaml

# Scheme B: Update router and LoRA parameters
tune run ./scripts/lora_train_dev.py --config ./configs/llama2_7B/7B_llama2_lora_mod.yaml

# Scheme C: Update router and all parameters
# tune run ./scripts/full_finetune_train.py --config ./configs/llama2_7B/7B_llama2_lora_mod.yaml
